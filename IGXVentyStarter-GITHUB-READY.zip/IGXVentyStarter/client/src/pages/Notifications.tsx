import { MainLayout } from "@/components/layout/MainLayout";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/button";
import { useApp } from "@/context/AppContext";
import { getUserById, demoPosts } from "@/data/seedData";
import { formatDistanceToNow } from "date-fns";
import { Link } from "wouter";

export default function Notifications() {
  const { notifications } = useApp();

  const getNotificationText = (notification: typeof notifications[0]) => {
    switch (notification.type) {
      case "like":
        return "liked your photo.";
      case "comment":
        return notification.text || "commented on your post.";
      case "follow":
        return "started following you.";
      case "mention":
        return "mentioned you in a comment.";
      default:
        return "";
    }
  };

  const getRelatedPost = (postId: string | undefined) => {
    if (!postId) return null;
    return demoPosts.find(p => p.id === postId);
  };

  const groupedNotifications = {
    today: notifications.filter(n => {
      const diff = Date.now() - new Date(n.timestamp).getTime();
      return diff < 24 * 60 * 60 * 1000;
    }),
    thisWeek: notifications.filter(n => {
      const diff = Date.now() - new Date(n.timestamp).getTime();
      return diff >= 24 * 60 * 60 * 1000 && diff < 7 * 24 * 60 * 60 * 1000;
    }),
    earlier: notifications.filter(n => {
      const diff = Date.now() - new Date(n.timestamp).getTime();
      return diff >= 7 * 24 * 60 * 60 * 1000;
    }),
  };

  const NotificationItem = ({ notification }: { notification: typeof notifications[0] }) => {
    const fromUser = getUserById(notification.fromUserId);
    const relatedPost = getRelatedPost(notification.postId);
    const timeAgo = formatDistanceToNow(new Date(notification.timestamp), { addSuffix: false });

    if (!fromUser) return null;

    return (
      <div 
        className={`flex items-center gap-3 p-4 ${!notification.isRead ? 'bg-blue-50 dark:bg-blue-950/20' : ''}`}
        data-testid={`notification-${notification.id}`}
      >
        <Link href={`/profile/${fromUser.username}`}>
          <Avatar src={fromUser.avatar} alt={fromUser.username} size="md" />
        </Link>
        
        <div className="flex-1 min-w-0">
          <p className="text-sm">
            <Link href={`/profile/${fromUser.username}`} className="font-semibold">
              {fromUser.username}
            </Link>{" "}
            {getNotificationText(notification)}{" "}
            <span className="text-gray-500">{timeAgo}</span>
          </p>
        </div>

        {notification.type === "follow" ? (
          <Button 
            size="sm"
            className="bg-blue-500 hover:bg-blue-600 text-white text-xs px-4"
            data-testid="follow-back-button"
          >
            Follow
          </Button>
        ) : relatedPost ? (
          <img
            src={relatedPost.images[0]}
            alt="Related post"
            className="w-11 h-11 object-cover"
          />
        ) : null}
      </div>
    );
  };

  const Section = ({ title, items }: { title: string; items: typeof notifications }) => {
    if (items.length === 0) return null;
    
    return (
      <div>
        <h2 className="px-4 py-2 text-sm font-semibold text-foreground">{title}</h2>
        <div className="divide-y divide-gray-100 dark:divide-gray-800">
          {items.map(notification => (
            <NotificationItem key={notification.id} notification={notification} />
          ))}
        </div>
      </div>
    );
  };

  return (
    <MainLayout>
      <div className="min-h-screen" data-testid="notifications-page">
        <div className="border-b border-gray-200 dark:border-gray-800 p-4">
          <h1 className="text-lg font-semibold">Notifications</h1>
        </div>

        {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-16">
            <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="text-gray-300 mb-4">
              <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
            </svg>
            <p className="text-gray-500 text-sm">No notifications yet</p>
          </div>
        ) : (
          <div>
            <Section title="Today" items={groupedNotifications.today} />
            <Section title="This Week" items={groupedNotifications.thisWeek} />
            <Section title="Earlier" items={groupedNotifications.earlier} />
          </div>
        )}
      </div>
    </MainLayout>
  );
}
