import type { User, Post, Story, Reel, Comment, Notification } from "@shared/schema";

// Demo Users (3 users as specified)
export const demoUsers: User[] = [
  {
    id: "user_1",
    username: "alex.travels",
    displayName: "Alex Thompson",
    avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    bio: "Travel photographer | Exploring the world one photo at a time",
    website: "alexthompson.com",
    isVerified: true,
    followersCount: 12500,
    followingCount: 890,
    postsCount: 234,
  },
  {
    id: "user_2",
    username: "sarah.foodie",
    displayName: "Sarah Chen",
    avatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&h=150&fit=crop&crop=face",
    bio: "Food blogger | Recipe developer | Coffee addict",
    website: "sarahsfoodblog.com",
    isVerified: false,
    followersCount: 8700,
    followingCount: 1200,
    postsCount: 456,
  },
  {
    id: "user_3",
    username: "mike.fitness",
    displayName: "Mike Rodriguez",
    avatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face",
    bio: "Fitness coach | Helping you reach your goals",
    website: "mikefitness.io",
    isVerified: true,
    followersCount: 45000,
    followingCount: 320,
    postsCount: 189,
  },
];

// Demo Posts (8 posts - mix of images/videos as specified)
export const demoPosts: Post[] = [
  {
    id: "post_1",
    userId: "user_1",
    images: [
      "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=470&h=470&fit=crop",
      "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=470&h=470&fit=crop",
      "https://images.unsplash.com/photo-1447752875215-b2761acb3c5d?w=470&h=470&fit=crop",
    ],
    caption: "Mountains calling and I must go. This trip was absolutely incredible! The views from the summit were breathtaking.",
    location: "Swiss Alps, Switzerland",
    likesCount: 2341,
    commentsCount: 89,
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    isVideo: false,
  },
  {
    id: "post_2",
    userId: "user_2",
    images: [
      "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=470&h=470&fit=crop",
    ],
    caption: "Homemade pizza night! Fresh basil, buffalo mozzarella, and San Marzano tomatoes. Recipe in bio!",
    location: "Home Kitchen",
    likesCount: 1567,
    commentsCount: 234,
    timestamp: new Date(Date.now() - 5 * 60 * 60 * 1000).toISOString(),
    isVideo: false,
  },
  {
    id: "post_3",
    userId: "user_3",
    images: [
      "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=470&h=470&fit=crop",
    ],
    caption: "Morning workout complete! Remember, consistency is key. Every rep counts toward your goals.",
    location: "Fitness First Gym",
    likesCount: 4521,
    commentsCount: 156,
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    isVideo: false,
  },
  {
    id: "post_4",
    userId: "user_1",
    images: [
      "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=470&h=470&fit=crop",
      "https://images.unsplash.com/photo-1433086966358-54859d0ed716?w=470&h=470&fit=crop",
    ],
    caption: "Sunrise at the lake. Waking up early was definitely worth it for this view.",
    location: "Lake Como, Italy",
    likesCount: 3892,
    commentsCount: 67,
    timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
    isVideo: false,
  },
  {
    id: "post_5",
    userId: "user_2",
    images: [
      "https://images.unsplash.com/photo-1567620905732-2d1ec7ab7445?w=470&h=470&fit=crop",
      "https://images.unsplash.com/photo-1540189549336-e6e99c3679fe?w=470&h=470&fit=crop",
      "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=470&h=470&fit=crop",
    ],
    caption: "Weekend brunch goals! New recipes coming to the blog this week.",
    location: "The Brunch Club",
    likesCount: 2156,
    commentsCount: 189,
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    isVideo: false,
  },
  {
    id: "post_6",
    userId: "user_3",
    images: [
      "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=470&h=470&fit=crop",
    ],
    caption: "New PR on deadlift! 405lbs. Hard work pays off. Stay focused on your journey.",
    location: "Iron Paradise Gym",
    likesCount: 6723,
    commentsCount: 312,
    timestamp: new Date(Date.now() - 36 * 60 * 60 * 1000).toISOString(),
    isVideo: true,
  },
  {
    id: "post_7",
    userId: "user_1",
    images: [
      "https://images.unsplash.com/photo-1682687220742-aba13b6e50ba?w=470&h=470&fit=crop",
    ],
    caption: "City lights at night. There's something magical about urban photography.",
    location: "Tokyo, Japan",
    likesCount: 5432,
    commentsCount: 98,
    timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    isVideo: false,
  },
  {
    id: "post_8",
    userId: "user_2",
    images: [
      "https://images.unsplash.com/photo-1551024506-0bccd828d307?w=470&h=470&fit=crop",
      "https://images.unsplash.com/photo-1563805042-7684c019e1cb?w=470&h=470&fit=crop",
    ],
    caption: "Dessert tasting menu! Each one more delicious than the last.",
    location: "Pastry Paradise",
    likesCount: 3211,
    commentsCount: 145,
    timestamp: new Date(Date.now() - 72 * 60 * 60 * 1000).toISOString(),
    isVideo: false,
  },
];

// Demo Stories (4 stories as specified)
export const demoStories: Story[] = [
  {
    id: "story_1",
    userId: "user_1",
    imageUrl: "https://images.unsplash.com/photo-1682687982501-1e58ab814714?w=400&h=700&fit=crop",
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 23 * 60 * 60 * 1000).toISOString(),
    isViewed: false,
    isVideo: false,
  },
  {
    id: "story_2",
    userId: "user_2",
    imageUrl: "https://images.unsplash.com/photo-1504674900247-0877df9cc836?w=400&h=700&fit=crop",
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 21 * 60 * 60 * 1000).toISOString(),
    isViewed: false,
    isVideo: false,
  },
  {
    id: "story_3",
    userId: "user_3",
    imageUrl: "https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=400&h=700&fit=crop",
    timestamp: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 18 * 60 * 60 * 1000).toISOString(),
    isViewed: true,
    isVideo: false,
  },
  {
    id: "story_4",
    userId: "user_1",
    imageUrl: "https://images.unsplash.com/photo-1501785888041-af3ef285b470?w=400&h=700&fit=crop",
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
    expiresAt: new Date(Date.now() + 16 * 60 * 60 * 1000).toISOString(),
    isViewed: false,
    isVideo: false,
  },
];

// Demo Reels
export const demoReels: Reel[] = [
  {
    id: "reel_1",
    userId: "user_1",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=700&fit=crop",
    caption: "Epic mountain adventure! The views were absolutely insane",
    audioName: "Original Audio",
    likesCount: 15234,
    commentsCount: 456,
    sharesCount: 234,
    timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "reel_2",
    userId: "user_2",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?w=400&h=700&fit=crop",
    caption: "Quick and easy pasta recipe! Save this for later",
    audioName: "Cooking Vibes",
    likesCount: 8923,
    commentsCount: 234,
    sharesCount: 567,
    timestamp: new Date(Date.now() - 8 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "reel_3",
    userId: "user_3",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=400&h=700&fit=crop",
    caption: "5 minute ab workout! No equipment needed",
    audioName: "Workout Beats",
    likesCount: 23456,
    commentsCount: 789,
    sharesCount: 1234,
    timestamp: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(),
  },
  {
    id: "reel_4",
    userId: "user_1",
    videoUrl: "https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    thumbnailUrl: "https://images.unsplash.com/photo-1476514525535-07fb3b4ae5f1?w=400&h=700&fit=crop",
    caption: "Sunset vibes at the beach",
    audioName: "Chill Beats",
    likesCount: 12345,
    commentsCount: 321,
    sharesCount: 456,
    timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
  },
];

// Demo Comments
export const demoComments: Comment[] = [
  {
    id: "comment_1",
    postId: "post_1",
    userId: "user_2",
    text: "Stunning views! I need to visit this place!",
    timestamp: new Date(Date.now() - 1 * 60 * 60 * 1000).toISOString(),
    likesCount: 23,
  },
  {
    id: "comment_2",
    postId: "post_1",
    userId: "user_3",
    text: "Amazing shot! What camera do you use?",
    timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    likesCount: 15,
  },
  {
    id: "comment_3",
    postId: "post_2",
    userId: "user_1",
    text: "This looks delicious! Saving this recipe!",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    likesCount: 45,
  },
];

// Demo Notifications
export const demoNotifications: Notification[] = [
  {
    id: "notif_1",
    userId: "user_1",
    fromUserId: "user_2",
    type: "like",
    postId: "post_1",
    timestamp: new Date(Date.now() - 15 * 60 * 1000).toISOString(),
    isRead: false,
  },
  {
    id: "notif_2",
    userId: "user_1",
    fromUserId: "user_3",
    type: "comment",
    postId: "post_1",
    text: "commented: Amazing shot!",
    timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    isRead: false,
  },
  {
    id: "notif_3",
    userId: "user_1",
    fromUserId: "user_2",
    type: "follow",
    timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    isRead: true,
  },
];

// Sample follows (to produce populated feed)
export const demoFollows = [
  { followerId: "user_1", followingId: "user_2" },
  { followerId: "user_1", followingId: "user_3" },
  { followerId: "user_2", followingId: "user_1" },
  { followerId: "user_2", followingId: "user_3" },
  { followerId: "user_3", followingId: "user_1" },
];

// Helper to get user by ID
export const getUserById = (id: string): User | undefined => {
  return demoUsers.find(user => user.id === id);
};

// Helper to get posts by user ID
export const getPostsByUserId = (userId: string): Post[] => {
  return demoPosts.filter(post => post.userId === userId);
};

// Helper to get stories grouped by user
export const getStoriesByUser = () => {
  const storiesByUser = new Map<string, Story[]>();
  demoStories.forEach(story => {
    const userStories = storiesByUser.get(story.userId) || [];
    userStories.push(story);
    storiesByUser.set(story.userId, userStories);
  });
  return storiesByUser;
};
