import { useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/Avatar";
import { IconButton } from "@/components/ui/IconButton";
import { ImageCarousel } from "./ImageCarousel";
import { HeartAnimation } from "./HeartAnimation";
import {
  HeartIcon,
  CommentIcon,
  ShareIcon,
  BookmarkIcon,
  MoreIcon,
  VerifiedIcon,
} from "@/components/icons/InstagramIcons";
import type { Post, User } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";
import { useApp } from "@/context/AppContext";
import { Link } from "wouter";

interface PostCardProps {
  post: Post;
  user: User;
}

export function PostCard({ post, user }: PostCardProps) {
  const { likedPosts, savedPosts, likePost, unlikePost, savePost, unsavePost } = useApp();
  const [showHeartAnimation, setShowHeartAnimation] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  
  const isLiked = likedPosts.has(post.id);
  const isSaved = savedPosts.has(post.id);

  const handleDoubleTap = useCallback(() => {
    if (!isLiked) {
      likePost(post.id);
    }
    setShowHeartAnimation(true);
    setTimeout(() => setShowHeartAnimation(false), 1000);
  }, [isLiked, likePost, post.id]);

  const handleLikeClick = useCallback(() => {
    if (isLiked) {
      unlikePost(post.id);
    } else {
      likePost(post.id);
    }
  }, [isLiked, likePost, unlikePost, post.id]);

  const handleSaveClick = useCallback(() => {
    if (isSaved) {
      unsavePost(post.id);
    } else {
      savePost(post.id);
    }
  }, [isSaved, savePost, unsavePost, post.id]);

  const formatCount = (count: number): string => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  const timeAgo = formatDistanceToNow(new Date(post.timestamp), { addSuffix: false });
  const displayCaption = post.caption || "";
  const shouldTruncate = displayCaption.length > 100;
  const truncatedCaption = shouldTruncate && !isExpanded 
    ? displayCaption.slice(0, 100) + "..." 
    : displayCaption;

  return (
    <article 
      className="bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800"
      data-testid={`post-card-${post.id}`}
    >
      {/* Header */}
      <header className="flex items-center justify-between p-3">
        <Link href={`/profile/${user.username}`} className="flex items-center gap-3">
          <Avatar 
            src={user.avatar} 
            alt={user.username} 
            size="sm"
          />
          <div className="flex items-center gap-1">
            <span className="font-semibold text-sm text-foreground" data-testid="post-username">
              {user.username}
            </span>
            {user.isVerified && <VerifiedIcon size={14} />}
          </div>
        </Link>
        <IconButton aria-label="More options" data-testid="post-more-button">
          <MoreIcon size={20} className="text-foreground" />
        </IconButton>
      </header>

      {/* Image Carousel */}
      <div className="relative">
        <ImageCarousel 
          images={post.images} 
          onDoubleTap={handleDoubleTap}
        />
        <HeartAnimation show={showHeartAnimation} />
      </div>

      {/* Action Bar */}
      <div className="flex items-center justify-between p-3">
        <div className="flex items-center gap-4">
          <IconButton 
            aria-label={isLiked ? "Unlike" : "Like"} 
            onClick={handleLikeClick}
            data-testid="post-like-button"
          >
            <HeartIcon 
              size={24} 
              filled={isLiked} 
              className={cn(
                "transition-colors",
                isLiked ? "text-red-500" : "text-foreground"
              )} 
            />
          </IconButton>
          <IconButton aria-label="Comment" data-testid="post-comment-button">
            <CommentIcon size={24} className="text-foreground" />
          </IconButton>
          <IconButton aria-label="Share" data-testid="post-share-button">
            <ShareIcon size={24} className="text-foreground" />
          </IconButton>
        </div>
        <IconButton 
          aria-label={isSaved ? "Unsave" : "Save"} 
          onClick={handleSaveClick}
          data-testid="post-save-button"
        >
          <BookmarkIcon 
            size={24} 
            filled={isSaved}
            className="text-foreground" 
          />
        </IconButton>
      </div>

      {/* Engagement Section */}
      <div className="px-3 pb-3 space-y-1">
        {/* Like count */}
        <p className="font-semibold text-sm text-foreground" data-testid="post-like-count">
          {formatCount(post.likesCount)} likes
        </p>

        {/* Caption */}
        {post.caption && (
          <p className="text-sm text-foreground">
            <Link href={`/profile/${user.username}`} className="font-semibold mr-1">
              {user.username}
            </Link>
            <span>{truncatedCaption}</span>
            {shouldTruncate && !isExpanded && (
              <button 
                onClick={() => setIsExpanded(true)}
                className="text-gray-500 ml-1"
                data-testid="post-expand-caption"
              >
                more
              </button>
            )}
          </p>
        )}

        {/* View all comments */}
        {post.commentsCount > 0 && (
          <button 
            className="text-sm text-gray-500 dark:text-gray-400"
            data-testid="post-view-comments"
          >
            View all {post.commentsCount} comments
          </button>
        )}

        {/* Timestamp */}
        <p className="text-xs text-gray-500 dark:text-gray-400 uppercase" data-testid="post-timestamp">
          {timeAgo} ago
        </p>
      </div>

      {/* Comment Input */}
      <div className="px-3 pb-3 border-t border-gray-100 dark:border-gray-800 pt-3">
        <div className="flex items-center gap-3">
          <input
            type="text"
            placeholder="Add a comment..."
            className="flex-1 text-sm bg-transparent outline-none placeholder:text-gray-500"
            data-testid="post-comment-input"
          />
          <button 
            className="text-sm font-semibold text-blue-500 opacity-50"
            disabled
            data-testid="post-comment-submit"
          >
            Post
          </button>
        </div>
      </div>
    </article>
  );
}

export function PostCardSkeleton() {
  return (
    <div className="bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800 animate-pulse">
      {/* Header */}
      <div className="flex items-center gap-3 p-3">
        <div className="h-8 w-8 rounded-full bg-gray-200 dark:bg-gray-700" />
        <div className="h-4 w-24 bg-gray-200 dark:bg-gray-700 rounded" />
      </div>
      
      {/* Image */}
      <div className="aspect-square bg-gray-200 dark:bg-gray-700" />
      
      {/* Actions */}
      <div className="p-3 space-y-2">
        <div className="flex gap-4">
          <div className="h-6 w-6 bg-gray-200 dark:bg-gray-700 rounded" />
          <div className="h-6 w-6 bg-gray-200 dark:bg-gray-700 rounded" />
          <div className="h-6 w-6 bg-gray-200 dark:bg-gray-700 rounded" />
        </div>
        <div className="h-4 w-20 bg-gray-200 dark:bg-gray-700 rounded" />
        <div className="h-4 w-full bg-gray-200 dark:bg-gray-700 rounded" />
        <div className="h-4 w-3/4 bg-gray-200 dark:bg-gray-700 rounded" />
      </div>
    </div>
  );
}
