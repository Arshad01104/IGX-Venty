import { useState, useEffect, useCallback, useRef } from "react";
import { cn } from "@/lib/utils";
import { CloseIcon, ChevronLeftIcon, ChevronRightIcon } from "@/components/icons/InstagramIcons";
import { useApp } from "@/context/AppContext";
import type { User, Story } from "@shared/schema";
import { formatDistanceToNow } from "date-fns";

interface StoryViewerProps {
  user: User;
  stories: Story[];
  onClose: () => void;
  onNextUser: () => void;
  onPrevUser: () => void;
  hasNextUser: boolean;
  hasPrevUser: boolean;
}

const STORY_DURATION = 5000;

export function StoryViewer({
  user,
  stories,
  onClose,
  onNextUser,
  onPrevUser,
  hasNextUser,
  hasPrevUser,
}: StoryViewerProps) {
  const { markStoryViewed } = useApp();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  const currentStory = stories[currentIndex];

  const goToNext = useCallback(() => {
    if (currentIndex < stories.length - 1) {
      setCurrentIndex(prev => prev + 1);
      setProgress(0);
    } else {
      onNextUser();
    }
  }, [currentIndex, stories.length, onNextUser]);

  const goToPrev = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      setProgress(0);
    } else {
      onPrevUser();
    }
  }, [currentIndex, onPrevUser]);

  useEffect(() => {
    if (currentStory && !currentStory.isViewed) {
      markStoryViewed(currentStory.id);
    }
  }, [currentStory, markStoryViewed]);

  useEffect(() => {
    if (isPaused) {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
      return;
    }

    intervalRef.current = setInterval(() => {
      setProgress(prev => {
        if (prev >= 100) {
          goToNext();
          return 0;
        }
        return prev + (100 / (STORY_DURATION / 50));
      });
    }, 50);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [isPaused, goToNext]);

  useEffect(() => {
    setProgress(0);
  }, [currentIndex, user.id]);

  const handleTouchStart = () => setIsPaused(true);
  const handleTouchEnd = () => setIsPaused(false);

  const handleClick = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const thirdWidth = rect.width / 3;

    if (clickX < thirdWidth) {
      goToPrev();
    } else {
      goToNext();
    }
  };

  const handleKeyDown = useCallback((e: KeyboardEvent) => {
    if (e.key === "ArrowRight") goToNext();
    if (e.key === "ArrowLeft") goToPrev();
    if (e.key === "Escape") onClose();
  }, [goToNext, goToPrev, onClose]);

  useEffect(() => {
    document.addEventListener("keydown", handleKeyDown);
    document.body.style.overflow = "hidden";
    
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = "";
    };
  }, [handleKeyDown]);

  if (!currentStory) return null;

  const timeAgo = formatDistanceToNow(new Date(currentStory.timestamp), { addSuffix: false });

  return (
    <div 
      className="fixed inset-0 z-50 bg-black flex items-center justify-center"
      data-testid="story-viewer"
    >
      {/* Story Container */}
      <div 
        className="relative w-full h-full max-w-[420px] max-h-[750px] md:rounded-lg overflow-hidden"
        onClick={handleClick}
        onMouseDown={handleTouchStart}
        onMouseUp={handleTouchEnd}
        onTouchStart={handleTouchStart}
        onTouchEnd={handleTouchEnd}
      >
        {/* Story Image */}
        <img
          src={currentStory.imageUrl}
          alt="Story"
          className="w-full h-full object-cover"
        />

        {/* Gradient Overlay Top */}
        <div className="absolute inset-x-0 top-0 h-32 bg-gradient-to-b from-black/60 to-transparent" />

        {/* Progress Bars */}
        <div className="absolute top-2 left-2 right-2 flex gap-1" data-testid="story-progress-bars">
          {stories.map((_, index) => (
            <div 
              key={index} 
              className="flex-1 h-0.5 bg-white/30 rounded-full overflow-hidden"
            >
              <div
                className={cn(
                  "h-full bg-white transition-all duration-50",
                  index < currentIndex && "w-full",
                  index > currentIndex && "w-0"
                )}
                style={{
                  width: index === currentIndex ? `${progress}%` : undefined,
                }}
              />
            </div>
          ))}
        </div>

        {/* Header */}
        <div className="absolute top-6 left-3 right-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={user.avatar}
              alt={user.username}
              className="w-8 h-8 rounded-full border-2 border-white"
            />
            <span className="text-white font-semibold text-sm">{user.username}</span>
            <span className="text-white/70 text-sm">{timeAgo}</span>
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); onClose(); }}
            className="p-2"
            aria-label="Close story"
            data-testid="story-close-button"
          >
            <CloseIcon size={24} className="text-white" />
          </button>
        </div>

        {/* Navigation Arrows (desktop) */}
        {hasPrevUser && (
          <button
            onClick={(e) => { e.stopPropagation(); onPrevUser(); }}
            className="absolute left-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hidden md:flex hover:bg-white/30 transition-colors"
            aria-label="Previous user's story"
          >
            <ChevronLeftIcon size={24} className="text-white" />
          </button>
        )}
        {hasNextUser && (
          <button
            onClick={(e) => { e.stopPropagation(); onNextUser(); }}
            className="absolute right-2 top-1/2 -translate-y-1/2 w-10 h-10 rounded-full bg-white/20 flex items-center justify-center hidden md:flex hover:bg-white/30 transition-colors"
            aria-label="Next user's story"
          >
            <ChevronRightIcon size={24} className="text-white" />
          </button>
        )}

        {/* Reply Input */}
        <div className="absolute bottom-4 left-3 right-3">
          <input
            type="text"
            placeholder={`Reply to ${user.username}...`}
            className="w-full px-4 py-2 rounded-full bg-transparent border border-white/50 text-white placeholder:text-white/70 text-sm focus:outline-none focus:border-white"
            onClick={(e) => e.stopPropagation()}
            data-testid="story-reply-input"
          />
        </div>
      </div>
    </div>
  );
}
