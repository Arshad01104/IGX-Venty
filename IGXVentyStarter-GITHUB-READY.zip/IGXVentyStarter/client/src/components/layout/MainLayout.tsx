import type { ReactNode } from "react";
import { TopNavbar } from "./TopNavbar";
import { BottomNavbar } from "./BottomNavbar";

interface MainLayoutProps {
  children: ReactNode;
  hideNavbar?: boolean;
  hideBottomNav?: boolean;
}

export function MainLayout({ 
  children, 
  hideNavbar = false,
  hideBottomNav = false 
}: MainLayoutProps) {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-950">
      {!hideNavbar && <TopNavbar />}
      
      <main className={`
        max-w-[470px] mx-auto
        ${!hideBottomNav ? 'pb-14 md:pb-0' : ''}
      `}>
        {children}
      </main>
      
      {!hideBottomNav && <BottomNavbar />}
    </div>
  );
}
