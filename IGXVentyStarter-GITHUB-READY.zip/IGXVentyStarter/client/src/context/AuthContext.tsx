import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import {
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signOut,
  onAuthStateChanged,
  GoogleAuthProvider,
  signInWithPopup,
  updateProfile,
} from "firebase/auth";
import { auth, db } from "@/services/firebase";
import { doc, setDoc, getDoc } from "firebase/firestore";
import type { User } from "@shared/schema";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  loginWithGoogle: () => Promise<void>;
  signup: (email: string, password: string, username: string) => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (authUser) => {
      if (authUser) {
        try {
          const userDocRef = doc(db, "users", authUser.uid);
          const userDoc = await getDoc(userDocRef);
          
          if (userDoc.exists()) {
            const data = userDoc.data();
            setUser({
              id: data.id || authUser.uid,
              username: data.username || "",
              displayName: data.displayName || "",
              avatar: data.avatar || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
              bio: data.bio || "",
              website: data.website || "",
              followersCount: data.followersCount || 0,
              followingCount: data.followingCount || 0,
              postsCount: data.postsCount || 0,
              isVerified: data.isVerified || false,
            } as User);
          } else {
            setUser({
              id: authUser.uid,
              username: authUser.displayName?.toLowerCase().replace(/\s+/g, ".") || authUser.email?.split("@")[0] || "user",
              displayName: authUser.displayName || authUser.email || "",
              avatar: authUser.photoURL || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
              bio: "",
              website: "",
              followersCount: 0,
              followingCount: 0,
              postsCount: 0,
              isVerified: false,
            } as User);
          }
        } catch (error) {
          console.error("Error fetching user:", error);
          setUser(null);
        }
      } else {
        setUser(null);
      }
      setIsLoading(false);
    });

    return unsubscribe;
  }, []);

  const login = async (email: string, password: string) => {
    setIsLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (error: any) {
      console.error("Firebase sign in error:", error);
      throw error;
    } finally {
      setIsLoading(false);
    }
  };

  const loginWithGoogle = async () => {
    setIsLoading(true);
    try {
      const provider = new GoogleAuthProvider();
      const result = await signInWithPopup(auth, provider);
      
      // Check if user doc exists, if not create it
      const userDocRef = doc(db, "users", result.user.uid);
      const userDoc = await getDoc(userDocRef);
      
      if (!userDoc.exists()) {
        const username = result.user.displayName?.toLowerCase().replace(/\s+/g, ".") || result.user.email?.split("@")[0] || "user";
        await setDoc(userDocRef, {
          id: result.user.uid,
          username,
          displayName: result.user.displayName || result.user.email || "",
          avatar: result.user.photoURL || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
          bio: "",
          website: "",
          followersCount: 0,
          followingCount: 0,
          postsCount: 0,
          isVerified: false,
        });
      }
    } finally {
      setIsLoading(false);
    }
  };

  const signup = async (email: string, password: string, username: string) => {
    setIsLoading(true);
    try {
      const result = await createUserWithEmailAndPassword(auth, email, password);
      
      // Create user document in Firestore
      const userDocRef = doc(db, "users", result.user.uid);
      await setDoc(userDocRef, {
        id: result.user.uid,
        username,
        displayName: username,
        avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
        bio: "",
        website: "",
        followersCount: 0,
        followingCount: 0,
        postsCount: 0,
        isVerified: false,
      });
      
      await updateProfile(result.user, { displayName: username });
    } finally {
      setIsLoading(false);
    }
  };

  const logout = async () => {
    setIsLoading(true);
    try {
      await signOut(auth);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      isLoading,
      isAuthenticated: !!user,
      login,
      loginWithGoogle,
      signup,
      logout,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    console.error("useAuth called outside AuthProvider");
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}
