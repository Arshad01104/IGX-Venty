import { createContext, useContext, useState, useCallback, useEffect, type ReactNode } from "react";
import { collection, query, orderBy, limit, getDocs, doc, getDoc } from "firebase/firestore";
import { db } from "@/services/firebase";
import { useAuth } from "./AuthContext";
import type { User, Post, Story, Notification } from "@shared/schema";

interface AppContextType {
  currentUser: User | null;
  posts: Post[];
  stories: Story[];
  notifications: Notification[];
  likedPosts: Set<string>;
  savedPosts: Set<string>;
  likePost: (postId: string) => void;
  unlikePost: (postId: string) => void;
  savePost: (postId: string) => void;
  unsavePost: (postId: string) => void;
  markStoryViewed: (storyId: string) => void;
  getUserById: (id: string) => Promise<User | undefined>;
  getStoriesByUserId: (userId: string) => Story[];
  getUnreadStoriesCount: () => number;
  loadingPosts: boolean;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const { user: currentUser } = useAuth();
  const [posts, setPosts] = useState<Post[]>([]);
  const [stories, setStories] = useState<Story[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [likedPosts, setLikedPosts] = useState<Set<string>>(new Set());
  const [savedPosts, setSavedPosts] = useState<Set<string>>(new Set());
  const [loadingPosts, setLoadingPosts] = useState(true);

  // Load posts from Firestore
  useEffect(() => {
    const loadPosts = async () => {
      try {
        setLoadingPosts(true);
        const postsQuery = query(
          collection(db, "posts"),
          orderBy("timestamp", "desc"),
          limit(20)
        );
        const postsSnapshot = await getDocs(postsQuery);
        const postsData = postsSnapshot.docs.map(doc => ({
          ...doc.data(),
          id: doc.id,
        })) as Post[];
        setPosts(postsData);
      } catch (error) {
        console.error("Error loading posts:", error);
      } finally {
        setLoadingPosts(false);
      }
    };

    loadPosts();
  }, []);

  // Load stories from Firestore
  useEffect(() => {
    const loadStories = async () => {
      try {
        const now = new Date();
        const storiesQuery = query(
          collection(db, "stories"),
          orderBy("timestamp", "desc")
        );
        const storiesSnapshot = await getDocs(storiesQuery);
        const storiesData = storiesSnapshot.docs
          .map(doc => ({
            ...doc.data(),
            id: doc.id,
          }))
          .filter(story => new Date(story.expiresAt) > now) as Story[];
        setStories(storiesData);
      } catch (error) {
        console.error("Error loading stories:", error);
      }
    };

    loadStories();
  }, []);

  // Load notifications for current user
  useEffect(() => {
    if (!currentUser) return;

    const loadNotifications = async () => {
      try {
        const notificationsQuery = query(
          collection(db, `users/${currentUser.id}/notifications`),
          orderBy("timestamp", "desc"),
          limit(50)
        );
        const notificationsSnapshot = await getDocs(notificationsQuery);
        const notificationsData = notificationsSnapshot.docs.map(doc => ({
          ...doc.data(),
          id: doc.id,
        })) as Notification[];
        setNotifications(notificationsData);
      } catch (error) {
        console.error("Error loading notifications:", error);
      }
    };

    loadNotifications();
  }, [currentUser]);

  const likePost = useCallback((postId: string) => {
    if (!currentUser) return;
    
    setLikedPosts(prev => new Set(prev).add(postId));
    setPosts(prev => prev.map(post => 
      post.id === postId ? { ...post, likesCount: post.likesCount + 1 } : post
    ));
  }, [currentUser]);

  const unlikePost = useCallback((postId: string) => {
    if (!currentUser) return;
    
    setLikedPosts(prev => {
      const newSet = new Set(prev);
      newSet.delete(postId);
      return newSet;
    });
    setPosts(prev => prev.map(post => 
      post.id === postId ? { ...post, likesCount: Math.max(0, post.likesCount - 1) } : post
    ));
  }, [currentUser]);

  const savePost = useCallback((postId: string) => {
    setSavedPosts(prev => new Set(prev).add(postId));
  }, []);

  const unsavePost = useCallback((postId: string) => {
    setSavedPosts(prev => {
      const newSet = new Set(prev);
      newSet.delete(postId);
      return newSet;
    });
  }, []);

  const markStoryViewed = useCallback((storyId: string) => {
    setStories(prev => prev.map(story =>
      story.id === storyId ? { ...story, isViewed: true } : story
    ));
  }, []);

  const getUserById = useCallback(async (id: string): Promise<User | undefined> => {
    try {
      const userDocRef = doc(db, "users", id);
      const userDoc = await getDoc(userDocRef);
      if (userDoc.exists()) {
        return userDoc.data() as User;
      }
    } catch (error) {
      console.error("Error fetching user:", error);
    }
    return undefined;
  }, []);

  const getStoriesByUserId = useCallback((userId: string): Story[] => {
    return stories.filter(story => story.userId === userId);
  }, [stories]);

  const getUnreadStoriesCount = useCallback((): number => {
    return stories.filter(story => !story.isViewed).length;
  }, [stories]);

  return (
    <AppContext.Provider value={{
      currentUser,
      posts,
      stories,
      notifications,
      likedPosts,
      savedPosts,
      likePost,
      unlikePost,
      savePost,
      unsavePost,
      markStoryViewed,
      getUserById,
      getStoriesByUserId,
      getUnreadStoriesCount,
      loadingPosts,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error("useApp must be used within an AppProvider");
  }
  return context;
}
