# IGX-Venty - Instagram Clone

## Project Overview
IGX-Venty is a pixel-perfect Instagram-style social media application built with React, Vite, Express, and Firebase. The app replicates Instagram's mobile web UI/UX including posts, stories, reels, and real-time interactions with **real Firebase authentication and Firestore data**.

## Tech Stack
- **Frontend**: React 18 + Vite + TypeScript
- **Backend**: Express.js + TypeScript
- **Styling**: Tailwind CSS + shadcn/ui components
- **Database/Auth**: Firebase (Firestore, Auth, Storage)
- **State Management**: React Context + TanStack Query
- **Routing**: Wouter

## Project Structure
```
├── client/src/
│   ├── components/
│   │   ├── icons/          # Instagram-style SVG icons
│   │   ├── layout/         # TopNavbar, BottomNavbar, MainLayout
│   │   ├── post/           # PostCard, ImageCarousel, HeartAnimation
│   │   ├── stories/        # StoryRing, StoriesRow, StoryViewer
│   │   └── ui/             # shadcn components + Avatar, IconButton, ThemeToggle
│   ├── context/            # AppContext, AuthContext, ThemeContext
│   ├── pages/              # Home, Profile, Explore, Reels, CreatePost, etc.
│   └── services/           # firebase.ts (initialized), api.ts
├── server/
│   ├── routes.ts           # Express API endpoints (with TODOs for Firebase)
│   └── storage.ts          # In-memory storage interface
├── shared/
│   └── schema.ts           # TypeScript types/interfaces
├── firestore.rules         # Firestore security rules (deploy these!)
└── storage.rules           # Firebase Storage security rules (deploy these!)
```

## Firebase Integration Status
✅ **COMPLETE** - The app now uses real Firebase for:
- **Authentication**: Email/Password + Google Sign-In
- **Firestore**: Real-time data loading for posts, stories, notifications, user profiles
- **Storage**: Image/video uploads for posts and stories
- **Realtime**: Users see real data from other users in the app

## User Features (Live)
- **Sign Up / Login**: Create account with email or Google
- **Create Posts**: Upload images/videos with captions directly to Firebase Storage
- **Feed**: Infinite scroll showing real posts from all users
- **Profile**: View user profiles with their posts (dynamic)
- **Stories**: Share stories visible to all users (24hr expiry)
- **Notifications**: Real-time notifications (marked with TODOs for completion)
- **Messages**: Messaging UI ready (TODO: implement)
- **Explore**: Discover posts from all users
- **Reels**: Watch and create vertical videos

## Installation & Setup

### Prerequisites
- Node.js 18+
- Firebase Project (create at https://firebase.google.com)

### Environment Variables
Create a `.env.local` file or add to Replit Secrets:
```
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_APP_ID=your_app_id
```

### Firebase Setup Checklist
1. ✅ Enable Authentication (Email/Password + Google)
2. ✅ Create Firestore database
3. ✅ Set up Storage bucket
4. ⚠️ **Deploy security rules** (CRITICAL):
   ```bash
   firebase deploy --only firestore:rules,storage:rules
   ```
5. ✅ Add authorized domains in Firebase Console

### Deploy Security Rules
```bash
# Install Firebase CLI if needed
npm install -g firebase-tools

# Login to Firebase
firebase login

# Deploy rules
firebase deploy --only firestore:rules,storage:rules
```

## Running Locally
```bash
npm install
npm run dev
```
Visit http://localhost:5000

## Firestore Collections Structure
```
users/{uid}
  - id: string
  - username: string
  - displayName: string
  - avatar: string
  - bio: string
  - website: string
  - followersCount: number
  - followingCount: number
  - postsCount: number
  - isVerified: boolean

posts/{postId}
  - userId: string
  - images: array[string]
  - caption: string
  - location: string
  - likesCount: number
  - commentsCount: number
  - timestamp: timestamp
  - isVideo: boolean

stories/{storyId}
  - userId: string
  - imageUrl: string
  - timestamp: timestamp
  - expiresAt: timestamp
  - isViewed: boolean

likes/{likeId}
  - userId: string
  - postId: string
  - timestamp: timestamp

follows/{followId}
  - followerId: string
  - followingId: string
  - timestamp: timestamp

notifications/{notificationId}
  - userId: string
  - fromUserId: string
  - type: "like" | "comment" | "follow" | "mention"
  - postId: string (optional)
  - timestamp: timestamp
  - isRead: boolean
```

## Recent Changes (Real Firebase Migration)
- ✅ Removed all demo/seed data
- ✅ AuthContext now uses Firebase Auth (Email + Google)
- ✅ AppContext loads real data from Firestore
- ✅ CreatePost uploads to Firebase Storage
- ✅ Profile page queries Firestore for user data
- ✅ Home feed uses real Firestore queries with infinite scroll
- ✅ ThemeProvider for dark mode support

## What's Next
- Implement like/unlike with Firestore
- Complete notifications system
- Add messaging functionality
- Implement follow/unfollow
- Add image filters and editing
- Deploy to production

## Development Notes
- Dark mode is fully supported via ThemeToggle in navbar
- All interactive elements have data-testid for testing
- Error handling in place for Firebase operations
- Skeleton loaders show while data loads
- Real-time features ready for Firestore listeners

## Support
For Firebase setup issues, check:
- Firebase Console: https://console.firebase.google.com
- Firestore Rules: Check `firestore.rules` file
- Storage Rules: Check `storage.rules` file
