# IGX-Venty Design Guidelines

## Design Approach
**Reference-Based: Instagram Mobile Web Clone**
This project requires pixel-perfect replication of Instagram's mobile web interface. All design decisions should mirror Instagram's current visual language, spacing, and interaction patterns.

## Layout System

**Mobile-First Architecture**
- Single-column feed layout (max-width: 470px centered on desktop)
- Spacing: Use Tailwind units of 2, 3, 4, and 6 consistently (p-2, p-3, p-4, gap-6)
- Container padding: px-3 or px-4 for mobile content areas

**Navigation Structure**
- **Top Navbar**: Fixed, white background, border-bottom
  - Left: IGX logo (Instagram-style script font)
  - Center: Search bar with icon (placeholder on mobile)
  - Right: Icon cluster (Create, Messages, Notifications, Profile Avatar)
  
- **Bottom Nav Bar** (Mobile only, fixed): Home, Search, Reels, Create (+), Activity (heart), Profile icons
  - Height: h-12, evenly distributed icons

## Typography

**Font Stack**
- Primary: System fonts (-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial)
- Weights: 400 (regular), 600 (semibold for usernames/counts)

**Text Hierarchy**
- Usernames: text-sm font-semibold
- Captions: text-sm font-normal
- Timestamps: text-xs text-gray-500
- Action counts: text-sm font-semibold
- Button text: text-sm font-semibold

## Component Library

### Post Card (Instagram-exact order)
1. **Header**: flex items-center p-3, avatar (h-8 w-8 rounded-full), username, three-dot menu
2. **Image Carousel**: Square aspect-ratio (1:1), swipe enabled, page indicators (dots) overlay bottom
3. **Action Bar**: p-3, flex justify-between
   - Left: Like (heart), Comment (bubble), Share (paper plane) - gap-4
   - Right: Save (bookmark)
4. **Engagement Section** (px-3):
   - Like count: font-semibold
   - Caption: Username (bold) + text (truncate with "more")
   - "View all X comments" link (text-gray-500)
5. **Footer**: px-3 pb-3
   - Timestamp (uppercase, text-xs, text-gray-500)
   - Comment input placeholder ("Add a comment...")

### Stories Row
- Horizontal scroll, no scrollbar
- Story Ring: h-16 w-16, circular border (gradient ring for unread, gray for read)
- Avatar: h-14 w-14 centered inside ring
- Username: text-xs truncate, centered below

### Story Viewer (Full-screen overlay)
- Dark background (#000)
- Progress bars top (thin white bars, animate fill)
- Tap zones: left 1/3 = previous, right 2/3 = next
- Close button (X) top-right

### Reels Player
- Full viewport height sections (100vh)
- Snap scroll (scroll-snap-type: y mandatory)
- Overlay UI (right side, absolute):
  - Profile avatar (circular)
  - Like count + icon
  - Comment count + icon
  - Share icon
  - More menu (three dots)
- Bottom: Username + caption overlay, audio info

## Animations

**Interaction Feedback**
- Double-tap like: Heart icon scale animation (scale 0 → 1.2 → 1, then fade out)
- Button taps: Quick scale (0.95) on active state
- Story auto-advance: 5-second timer with progress bar fill animation
- Reel scroll: Snap to section with smooth easing

## Images

**Demo Content Images**
- Post images: Use placeholder services (Unsplash API) for lifestyle/photography content (470x470px square)
- Story images: Vertical format (9:16 ratio)
- Reel videos: Vertical format (9:16 ratio, use poster images initially)
- Profile avatars: Circular 150x150px placeholders
- Feed placement: Every post card contains one primary square image (image carousel for multiple)

**No Hero Images**: This is a feed-based app, not a marketing site. Content starts immediately with stories row and feed.

## Accessibility

- All interactive elements: min-height 44px for tap targets
- Icon buttons: aria-labels for screen readers
- Form inputs: Proper labels (can be sr-only for visual design)
- Focus states: 2px blue ring on keyboard navigation

## Skeleton Loaders

- Post card skeleton: Gray boxes matching exact post card structure (header, square, actions, text lines)
- Stories skeleton: 5-6 circular gray placeholders
- Animation: Subtle pulse (animate-pulse) or shimmer effect

## Quality Standards

- Border colors: border-gray-300 for separators
- Icon size: w-6 h-6 for action buttons, w-5 h-5 for nav items
- Avatar borders: White 2px border for stories
- Shadow: None (Instagram uses flat design)
- Infinite scroll: Load more posts when user is 200px from bottom