import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";

// TODO: Import Firebase Admin SDK when configuring server-side Firebase
// import { initializeApp, cert } from 'firebase-admin/app';
// import { getAuth } from 'firebase-admin/auth';
// import { getFirestore } from 'firebase-admin/firestore';

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // ============================================
  // Authentication Routes
  // TODO: Integrate with Firebase Admin SDK
  // ============================================
  
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    // TODO: Verify Firebase ID token
    // const { idToken } = req.body;
    // const decodedToken = await getAuth().verifyIdToken(idToken);
    // const user = await storage.getUser(decodedToken.uid);
    res.json({ message: "Login endpoint - TODO: Implement Firebase Auth" });
  });

  app.post("/api/auth/signup", async (req: Request, res: Response) => {
    // TODO: Create user in Firebase Auth and Firestore
    // const { email, password, username } = req.body;
    res.json({ message: "Signup endpoint - TODO: Implement Firebase Auth" });
  });

  app.post("/api/auth/logout", async (req: Request, res: Response) => {
    // TODO: Invalidate session/token
    res.json({ message: "Logged out successfully" });
  });

  app.get("/api/auth/me", async (req: Request, res: Response) => {
    // TODO: Get current user from Firebase token
    // const authHeader = req.headers.authorization;
    // if (!authHeader) return res.status(401).json({ error: "Unauthorized" });
    res.json({ message: "Get current user - TODO: Implement Firebase Auth" });
  });

  // ============================================
  // Users Routes
  // ============================================

  app.get("/api/users/:id", async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  app.get("/api/users/username/:username", async (req: Request, res: Response) => {
    try {
      const user = await storage.getUserByUsername(req.params.username);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  app.get("/api/users/search", async (req: Request, res: Response) => {
    try {
      const query = req.query.q as string || "";
      const users = await storage.searchUsers(query);
      res.json(users);
    } catch (error) {
      res.status(500).json({ error: "Failed to search users" });
    }
  });

  app.patch("/api/users/profile", async (req: Request, res: Response) => {
    // TODO: Get userId from Firebase token
    // const userId = req.user.id;
    res.json({ message: "Update profile - TODO: Implement with auth" });
  });

  // ============================================
  // Posts Routes
  // ============================================

  app.get("/api/posts/feed", async (req: Request, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = parseInt(req.query.offset as string) || 0;
      const posts = await storage.getPosts(limit, offset);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get feed" });
    }
  });

  app.get("/api/posts/:id", async (req: Request, res: Response) => {
    try {
      const post = await storage.getPost(req.params.id);
      if (!post) {
        return res.status(404).json({ error: "Post not found" });
      }
      res.json(post);
    } catch (error) {
      res.status(500).json({ error: "Failed to get post" });
    }
  });

  app.get("/api/posts/user/:userId", async (req: Request, res: Response) => {
    try {
      const posts = await storage.getPostsByUser(req.params.userId);
      res.json(posts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user posts" });
    }
  });

  app.post("/api/posts", async (req: Request, res: Response) => {
    // TODO: Get userId from Firebase token
    // TODO: Upload images to Firebase Storage first
    // const { images, caption, location } = req.body;
    res.json({ message: "Create post - TODO: Implement with Firebase Storage" });
  });

  app.delete("/api/posts/:id", async (req: Request, res: Response) => {
    try {
      // TODO: Verify user owns this post
      const deleted = await storage.deletePost(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Post not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete post" });
    }
  });

  // ============================================
  // Likes Routes
  // ============================================

  app.post("/api/likes/post/:postId", async (req: Request, res: Response) => {
    // TODO: Get userId from Firebase token
    // const like = await storage.createLike({ userId, postId: req.params.postId, timestamp: new Date().toISOString() });
    res.json({ message: "Like post - TODO: Implement with auth" });
  });

  app.delete("/api/likes/post/:postId", async (req: Request, res: Response) => {
    // TODO: Get userId from Firebase token
    // const deleted = await storage.deleteLike(userId, req.params.postId);
    res.json({ message: "Unlike post - TODO: Implement with auth" });
  });

  app.get("/api/likes/post/:postId", async (req: Request, res: Response) => {
    try {
      const likes = await storage.getLikesByPost(req.params.postId);
      res.json(likes);
    } catch (error) {
      res.status(500).json({ error: "Failed to get likes" });
    }
  });

  // ============================================
  // Comments Routes
  // ============================================

  app.get("/api/comments/post/:postId", async (req: Request, res: Response) => {
    try {
      const comments = await storage.getCommentsByPost(req.params.postId);
      res.json(comments);
    } catch (error) {
      res.status(500).json({ error: "Failed to get comments" });
    }
  });

  app.post("/api/comments", async (req: Request, res: Response) => {
    // TODO: Get userId from Firebase token
    // const { postId, text } = req.body;
    // const comment = await storage.createComment({ userId, postId, text, timestamp, likesCount: 0 });
    res.json({ message: "Add comment - TODO: Implement with auth" });
  });

  app.delete("/api/comments/:id", async (req: Request, res: Response) => {
    try {
      // TODO: Verify user owns this comment
      const deleted = await storage.deleteComment(req.params.id);
      if (!deleted) {
        return res.status(404).json({ error: "Comment not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete comment" });
    }
  });

  // ============================================
  // Follow Routes
  // ============================================

  app.post("/api/follow/:userId", async (req: Request, res: Response) => {
    // TODO: Get followerId from Firebase token
    // const follow = await storage.createFollow({ followerId, followingId: req.params.userId, timestamp });
    res.json({ message: "Follow user - TODO: Implement with auth" });
  });

  app.delete("/api/follow/:userId", async (req: Request, res: Response) => {
    // TODO: Get followerId from Firebase token
    // const deleted = await storage.deleteFollow(followerId, req.params.userId);
    res.json({ message: "Unfollow user - TODO: Implement with auth" });
  });

  app.get("/api/follow/:userId/followers", async (req: Request, res: Response) => {
    try {
      const followers = await storage.getFollowers(req.params.userId);
      res.json(followers);
    } catch (error) {
      res.status(500).json({ error: "Failed to get followers" });
    }
  });

  app.get("/api/follow/:userId/following", async (req: Request, res: Response) => {
    try {
      const following = await storage.getFollowing(req.params.userId);
      res.json(following);
    } catch (error) {
      res.status(500).json({ error: "Failed to get following" });
    }
  });

  // ============================================
  // Notifications Routes
  // ============================================

  app.get("/api/notifications", async (req: Request, res: Response) => {
    // TODO: Get userId from Firebase token
    // const notifications = await storage.getNotificationsByUser(userId);
    res.json({ message: "Get notifications - TODO: Implement with auth" });
  });

  app.patch("/api/notifications/:id/read", async (req: Request, res: Response) => {
    try {
      const marked = await storage.markNotificationRead(req.params.id);
      if (!marked) {
        return res.status(404).json({ error: "Notification not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark notification as read" });
    }
  });

  app.patch("/api/notifications/read-all", async (req: Request, res: Response) => {
    // TODO: Get userId from Firebase token
    // const marked = await storage.markAllNotificationsRead(userId);
    res.json({ message: "Mark all read - TODO: Implement with auth" });
  });

  // ============================================
  // Stories Routes
  // ============================================

  app.get("/api/stories", async (req: Request, res: Response) => {
    try {
      const stories = await storage.getActiveStories();
      res.json(stories);
    } catch (error) {
      res.status(500).json({ error: "Failed to get stories" });
    }
  });

  app.post("/api/stories", async (req: Request, res: Response) => {
    // TODO: Get userId from Firebase token
    // TODO: Upload image to Firebase Storage
    // const { imageUrl } = req.body;
    // const expiresAt = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
    // const story = await storage.createStory({ userId, imageUrl, timestamp, expiresAt, isViewed: false, isVideo: false });
    res.json({ message: "Create story - TODO: Implement with Firebase Storage" });
  });

  app.post("/api/stories/:id/view", async (req: Request, res: Response) => {
    try {
      const marked = await storage.markStoryViewed(req.params.id);
      if (!marked) {
        return res.status(404).json({ error: "Story not found" });
      }
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to mark story as viewed" });
    }
  });

  // ============================================
  // Reels Routes
  // ============================================

  app.get("/api/reels", async (req: Request, res: Response) => {
    try {
      const limit = parseInt(req.query.limit as string) || 10;
      const offset = parseInt(req.query.offset as string) || 0;
      const reels = await storage.getReels(limit, offset);
      res.json(reels);
    } catch (error) {
      res.status(500).json({ error: "Failed to get reels" });
    }
  });

  app.get("/api/reels/:id", async (req: Request, res: Response) => {
    try {
      const reel = await storage.getReel(req.params.id);
      if (!reel) {
        return res.status(404).json({ error: "Reel not found" });
      }
      res.json(reel);
    } catch (error) {
      res.status(500).json({ error: "Failed to get reel" });
    }
  });

  app.post("/api/reels", async (req: Request, res: Response) => {
    // TODO: Get userId from Firebase token
    // TODO: Upload video to Firebase Storage
    // const { videoUrl, caption } = req.body;
    res.json({ message: "Create reel - TODO: Implement with Firebase Storage" });
  });

  return httpServer;
}
