import { z } from "zod";

// User Schema
export const userSchema = z.object({
  id: z.string(),
  username: z.string(),
  displayName: z.string(),
  avatar: z.string(),
  bio: z.string().optional(),
  website: z.string().optional(),
  isVerified: z.boolean().default(false),
  followersCount: z.number().default(0),
  followingCount: z.number().default(0),
  postsCount: z.number().default(0),
});

export type User = z.infer<typeof userSchema>;
export type InsertUser = Omit<User, "id">;

// Post Schema
export const postSchema = z.object({
  id: z.string(),
  userId: z.string(),
  images: z.array(z.string()),
  caption: z.string().optional(),
  location: z.string().optional(),
  likesCount: z.number().default(0),
  commentsCount: z.number().default(0),
  timestamp: z.string(),
  isVideo: z.boolean().default(false),
});

export type Post = z.infer<typeof postSchema>;
export type InsertPost = Omit<Post, "id">;

// Story Schema
export const storySchema = z.object({
  id: z.string(),
  userId: z.string(),
  imageUrl: z.string(),
  timestamp: z.string(),
  expiresAt: z.string(),
  isViewed: z.boolean().default(false),
  isVideo: z.boolean().default(false),
});

export type Story = z.infer<typeof storySchema>;
export type InsertStory = Omit<Story, "id">;

// Comment Schema
export const commentSchema = z.object({
  id: z.string(),
  postId: z.string(),
  userId: z.string(),
  text: z.string(),
  timestamp: z.string(),
  likesCount: z.number().default(0),
});

export type Comment = z.infer<typeof commentSchema>;
export type InsertComment = Omit<Comment, "id">;

// Like Schema
export const likeSchema = z.object({
  id: z.string(),
  userId: z.string(),
  postId: z.string().optional(),
  commentId: z.string().optional(),
  timestamp: z.string(),
});

export type Like = z.infer<typeof likeSchema>;
export type InsertLike = Omit<Like, "id">;

// Follow Schema
export const followSchema = z.object({
  id: z.string(),
  followerId: z.string(),
  followingId: z.string(),
  timestamp: z.string(),
});

export type Follow = z.infer<typeof followSchema>;
export type InsertFollow = Omit<Follow, "id">;

// Notification Schema
export const notificationSchema = z.object({
  id: z.string(),
  userId: z.string(),
  fromUserId: z.string(),
  type: z.enum(["like", "comment", "follow", "mention"]),
  postId: z.string().optional(),
  commentId: z.string().optional(),
  text: z.string().optional(),
  timestamp: z.string(),
  isRead: z.boolean().default(false),
});

export type Notification = z.infer<typeof notificationSchema>;
export type InsertNotification = Omit<Notification, "id">;

// Message Schema
export const messageSchema = z.object({
  id: z.string(),
  senderId: z.string(),
  receiverId: z.string(),
  text: z.string(),
  timestamp: z.string(),
  isRead: z.boolean().default(false),
});

export type Message = z.infer<typeof messageSchema>;
export type InsertMessage = Omit<Message, "id">;

// Reel Schema
export const reelSchema = z.object({
  id: z.string(),
  userId: z.string(),
  videoUrl: z.string(),
  thumbnailUrl: z.string(),
  caption: z.string().optional(),
  audioName: z.string().optional(),
  likesCount: z.number().default(0),
  commentsCount: z.number().default(0),
  sharesCount: z.number().default(0),
  timestamp: z.string(),
});

export type Reel = z.infer<typeof reelSchema>;
export type InsertReel = Omit<Reel, "id">;
