// API Service for IGX-Venty
// Centralizes all API calls to the backend

const API_BASE = "/api";

// Generic fetch wrapper with error handling
async function apiRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE}${endpoint}`;
  
  const config: RequestInit = {
    headers: {
      "Content-Type": "application/json",
      ...options.headers,
    },
    ...options,
  };

  const response = await fetch(url, config);
  
  if (!response.ok) {
    const error = await response.json().catch(() => ({ message: "Request failed" }));
    throw new Error(error.message || `HTTP error! status: ${response.status}`);
  }
  
  return response.json();
}

// Auth API
export const authApi = {
  // TODO: Implement when Firebase Auth is configured
  login: async (email: string, password: string) => {
    return apiRequest("/auth/login", {
      method: "POST",
      body: JSON.stringify({ email, password }),
    });
  },
  
  signup: async (email: string, password: string, username: string) => {
    return apiRequest("/auth/signup", {
      method: "POST",
      body: JSON.stringify({ email, password, username }),
    });
  },
  
  logout: async () => {
    return apiRequest("/auth/logout", { method: "POST" });
  },
  
  getCurrentUser: async () => {
    return apiRequest("/auth/me");
  },
};

// Posts API
export const postsApi = {
  getFeed: async (limit = 10, offset = 0) => {
    return apiRequest(`/posts/feed?limit=${limit}&offset=${offset}`);
  },
  
  getPost: async (id: string) => {
    return apiRequest(`/posts/${id}`);
  },
  
  createPost: async (data: { images: string[]; caption?: string; location?: string }) => {
    return apiRequest("/posts", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
  
  deletePost: async (id: string) => {
    return apiRequest(`/posts/${id}`, { method: "DELETE" });
  },
  
  getUserPosts: async (userId: string) => {
    return apiRequest(`/posts/user/${userId}`);
  },
};

// Likes API
export const likesApi = {
  likePost: async (postId: string) => {
    return apiRequest(`/likes/post/${postId}`, { method: "POST" });
  },
  
  unlikePost: async (postId: string) => {
    return apiRequest(`/likes/post/${postId}`, { method: "DELETE" });
  },
  
  getPostLikes: async (postId: string) => {
    return apiRequest(`/likes/post/${postId}`);
  },
};

// Comments API
export const commentsApi = {
  getComments: async (postId: string) => {
    return apiRequest(`/comments/post/${postId}`);
  },
  
  addComment: async (postId: string, text: string) => {
    return apiRequest("/comments", {
      method: "POST",
      body: JSON.stringify({ postId, text }),
    });
  },
  
  deleteComment: async (commentId: string) => {
    return apiRequest(`/comments/${commentId}`, { method: "DELETE" });
  },
};

// Follow API
export const followApi = {
  followUser: async (userId: string) => {
    return apiRequest(`/follow/${userId}`, { method: "POST" });
  },
  
  unfollowUser: async (userId: string) => {
    return apiRequest(`/follow/${userId}`, { method: "DELETE" });
  },
  
  getFollowers: async (userId: string) => {
    return apiRequest(`/follow/${userId}/followers`);
  },
  
  getFollowing: async (userId: string) => {
    return apiRequest(`/follow/${userId}/following`);
  },
};

// Notifications API
export const notificationsApi = {
  getNotifications: async () => {
    return apiRequest("/notifications");
  },
  
  markAsRead: async (notificationId: string) => {
    return apiRequest(`/notifications/${notificationId}/read`, { method: "PATCH" });
  },
  
  markAllAsRead: async () => {
    return apiRequest("/notifications/read-all", { method: "PATCH" });
  },
};

// Stories API
export const storiesApi = {
  getStories: async () => {
    return apiRequest("/stories");
  },
  
  createStory: async (imageUrl: string) => {
    return apiRequest("/stories", {
      method: "POST",
      body: JSON.stringify({ imageUrl }),
    });
  },
  
  markViewed: async (storyId: string) => {
    return apiRequest(`/stories/${storyId}/view`, { method: "POST" });
  },
};

// Reels API
export const reelsApi = {
  getReels: async (limit = 10, offset = 0) => {
    return apiRequest(`/reels?limit=${limit}&offset=${offset}`);
  },
  
  getReel: async (id: string) => {
    return apiRequest(`/reels/${id}`);
  },
  
  createReel: async (data: { videoUrl: string; caption?: string }) => {
    return apiRequest("/reels", {
      method: "POST",
      body: JSON.stringify(data),
    });
  },
};

// Users API
export const usersApi = {
  getUser: async (userId: string) => {
    return apiRequest(`/users/${userId}`);
  },
  
  getUserByUsername: async (username: string) => {
    return apiRequest(`/users/username/${username}`);
  },
  
  updateProfile: async (data: { displayName?: string; bio?: string; website?: string }) => {
    return apiRequest("/users/profile", {
      method: "PATCH",
      body: JSON.stringify(data),
    });
  },
  
  searchUsers: async (query: string) => {
    return apiRequest(`/users/search?q=${encodeURIComponent(query)}`);
  },
};

export default {
  auth: authApi,
  posts: postsApi,
  likes: likesApi,
  comments: commentsApi,
  follow: followApi,
  notifications: notificationsApi,
  stories: storiesApi,
  reels: reelsApi,
  users: usersApi,
};
