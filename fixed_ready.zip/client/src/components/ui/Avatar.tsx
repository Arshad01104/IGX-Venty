import { cn } from "@/lib/utils";

interface AvatarProps {
  src: string;
  alt: string;
  size?: "xs" | "sm" | "md" | "lg" | "xl";
  className?: string;
  hasStory?: boolean;
  hasUnreadStory?: boolean;
  onClick?: () => void;
}

const sizeClasses = {
  xs: "h-6 w-6",
  sm: "h-8 w-8",
  md: "h-10 w-10",
  lg: "h-14 w-14",
  xl: "h-20 w-20",
};

const ringClasses = {
  xs: "p-[1px]",
  sm: "p-[2px]",
  md: "p-[2px]",
  lg: "p-[2px]",
  xl: "p-[3px]",
};

export function Avatar({
  src,
  alt,
  size = "md",
  className,
  hasStory = false,
  hasUnreadStory = false,
  onClick,
}: AvatarProps) {
  const avatarContent = (
    <img
      src={src}
      alt={alt}
      className={cn(
        "rounded-full object-cover",
        sizeClasses[size],
        hasStory && "border-2 border-white dark:border-gray-900",
        className
      )}
      loading="lazy"
    />
  );

  if (hasStory) {
    return (
      <button
        onClick={onClick}
        className={cn(
          "rounded-full",
          ringClasses[size],
          hasUnreadStory
            ? "bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600"
            : "bg-gray-300 dark:bg-gray-600"
        )}
        data-testid="avatar-story-ring"
      >
        {avatarContent}
      </button>
    );
  }

  if (onClick) {
    return (
      <button onClick={onClick} data-testid="avatar-button">
        {avatarContent}
      </button>
    );
  }

  return avatarContent;
}

export function AvatarSkeleton({ size = "md" }: { size?: "xs" | "sm" | "md" | "lg" | "xl" }) {
  return (
    <div className={cn("rounded-full bg-gray-200 dark:bg-gray-700 animate-pulse", sizeClasses[size])} />
  );
}
