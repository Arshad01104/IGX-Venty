import { cn } from "@/lib/utils";
import type { ReactNode } from "react";

interface IconButtonProps {
  children: ReactNode;
  onClick?: () => void;
  className?: string;
  "aria-label": string;
  disabled?: boolean;
  "data-testid"?: string;
}

export function IconButton({
  children,
  onClick,
  className,
  "aria-label": ariaLabel,
  disabled = false,
  "data-testid": testId,
}: IconButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      aria-label={ariaLabel}
      data-testid={testId}
      className={cn(
        "flex items-center justify-center p-2 rounded-lg transition-transform active:scale-95",
        "hover:bg-gray-100 dark:hover:bg-gray-800",
        "focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-500",
        disabled && "opacity-50 cursor-not-allowed",
        className
      )}
    >
      {children}
    </button>
  );
}
