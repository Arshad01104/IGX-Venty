import { Link, useLocation } from "wouter";
import { useState } from "react";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/Avatar";
import {
  HomeIcon,
  SearchIcon,
  ReelsIcon,
  CreateIcon,
  HeartIcon,
} from "@/components/icons/InstagramIcons";
import { useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";

interface NavItemProps {
  href: string;
  icon: React.ReactNode;
  activeIcon: React.ReactNode;
  label: string;
  isActive: boolean;
}

function NavItem({ href, icon, activeIcon, label, isActive }: NavItemProps) {
  return (
    <Link 
      href={href} 
      className={cn(
        "flex items-center justify-center p-3 min-h-[44px]",
        "transition-transform active:scale-90"
      )}
      aria-label={label}
      data-testid={`nav-${label.toLowerCase()}`}
    >
      {isActive ? activeIcon : icon}
    </Link>
  );
}

export function BottomNavbar() {
  const [location, setLocation] = useLocation();
  const { currentUser } = useApp();
  const { logout } = useAuth();
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleLogout = async () => {
    try {
      await logout();
      setLocation("/login");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const navItems = [
    {
      href: "/",
      icon: <HomeIcon size={24} className="text-foreground" />,
      activeIcon: <HomeIcon size={24} filled className="text-foreground" />,
      label: "Home",
    },
    {
      href: "/explore",
      icon: <SearchIcon size={24} className="text-foreground" />,
      activeIcon: <SearchIcon size={24} className="text-foreground" />,
      label: "Search",
    },
    {
      href: "/reels",
      icon: <ReelsIcon size={24} className="text-foreground" />,
      activeIcon: <ReelsIcon size={24} filled className="text-foreground" />,
      label: "Reels",
    },
    {
      href: "/create",
      icon: <CreateIcon size={24} className="text-foreground" />,
      activeIcon: <CreateIcon size={24} className="text-foreground" />,
      label: "Create",
    },
    {
      href: "/notifications",
      icon: <HeartIcon size={24} className="text-foreground" />,
      activeIcon: <HeartIcon size={24} filled className="text-foreground" />,
      label: "Activity",
    },
  ];

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 z-40 bg-white dark:bg-gray-950 border-t border-gray-200 dark:border-gray-800 md:hidden"
      data-testid="bottom-navbar"
    >
      <div className="flex items-center justify-around h-12">
        {navItems.map((item) => (
          <NavItem
            key={item.href}
            {...item}
            isActive={location === item.href}
          />
        ))}
        
        {/* Profile */}
        {currentUser && (
          <div className="relative">
            <button 
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              className={cn(
                "flex items-center justify-center p-3 min-h-[44px]",
                "transition-transform active:scale-90"
              )}
              aria-label="Profile Menu"
              data-testid="nav-profile-mobile"
            >
              <div className={cn(
                "rounded-full",
                (location.startsWith("/profile") || showProfileMenu) && "ring-2 ring-foreground ring-offset-1"
              )}>
                <Avatar 
                  src={currentUser.avatar} 
                  alt={currentUser.username}
                  size="xs"
                />
              </div>
            </button>

            {/* Mobile Profile Menu */}
            {showProfileMenu && (
              <div className="absolute bottom-full right-0 mb-2 w-40 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-50" data-testid="mobile-profile-menu">
                <Link 
                  href={`/profile/${currentUser.username}`}
                  className="block w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 text-sm"
                  data-testid="mobile-menu-profile"
                >
                  Profile
                </Link>
                <button
                  onClick={handleLogout}
                  className="block w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 text-sm text-red-600 dark:text-red-400 border-t border-gray-200 dark:border-gray-700 rounded-b-lg"
                  data-testid="mobile-button-logout"
                >
                  Log out
                </button>
              </div>
            )}
          </div>
        )}
      </div>
    </nav>
  );
}
