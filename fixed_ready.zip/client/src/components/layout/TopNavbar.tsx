import { Link, useLocation } from "wouter";
import { useState } from "react";
import { IconButton } from "@/components/ui/IconButton";
import { Avatar } from "@/components/ui/Avatar";
import { ThemeToggle } from "@/components/ui/ThemeToggle";
import { 
  CreateIcon, 
  HeartIcon, 
  MessengerIcon,
  SearchIcon,
  MoreIcon
} from "@/components/icons/InstagramIcons";
import { useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";

export function TopNavbar() {
  const [location, setLocation] = useLocation();
  const { currentUser, notifications } = useApp();
  const { logout } = useAuth();
  const [showMenu, setShowMenu] = useState(false);
  
  const unreadNotifications = notifications.filter(n => !n.isRead).length;

  const handleLogout = async () => {
    try {
      await logout();
      setLocation("/login");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <header 
      className="sticky top-0 z-40 bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800"
      data-testid="top-navbar"
    >
      <div className="flex items-center justify-between h-14 px-4 max-w-[935px] mx-auto">
        {/* Logo */}
        <Link href="/" className="flex items-center" data-testid="link-home">
          <h1 className="text-2xl font-semibold tracking-tight" style={{ fontFamily: "'Billabong', cursive" }} data-testid="text-logo">
            IGX
          </h1>
        </Link>

        {/* Search (hidden on mobile, visible on larger screens) */}
        <div className="hidden md:flex flex-1 max-w-[268px] mx-4">
          <div className="relative w-full">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <SearchIcon size={16} className="text-gray-400" />
            </div>
            <input
              type="search"
              placeholder="Search"
              className="w-full h-9 pl-10 pr-4 rounded-lg bg-gray-100 dark:bg-gray-800 text-sm placeholder:text-gray-500 focus:outline-none focus:ring-1 focus:ring-gray-300 dark:focus:ring-gray-600"
              data-testid="navbar-search"
            />
          </div>
        </div>

        {/* Action Icons */}
        <div className="flex items-center gap-1">
          <Link href="/create" data-testid="link-create">
            <IconButton aria-label="Create new post" data-testid="button-create">
              <CreateIcon size={24} className="text-foreground" />
            </IconButton>
          </Link>
          
          <Link href="/notifications" className="relative" data-testid="link-notifications">
            <IconButton aria-label="Notifications" data-testid="button-notifications">
              <HeartIcon 
                size={24} 
                filled={location === "/notifications"}
                className="text-foreground" 
              />
              {unreadNotifications > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-red-500 rounded-full text-[10px] text-white flex items-center justify-center font-semibold" data-testid="badge-unread-notifications">
                  {unreadNotifications > 9 ? "9+" : unreadNotifications}
                </span>
              )}
            </IconButton>
          </Link>
          
          <Link href="/messages" data-testid="link-messages">
            <IconButton aria-label="Messages" data-testid="button-messages">
              <MessengerIcon 
                size={24}
                filled={location === "/messages"}
                className="text-foreground" 
              />
            </IconButton>
          </Link>

          {/* Theme Toggle */}
          <ThemeToggle />

          {/* Profile Menu (visible on desktop) */}
          {currentUser && (
            <div className="hidden md:flex items-center gap-1 ml-2 relative">
              <Link href={`/profile/${currentUser.username}`} data-testid="link-profile">
                <Avatar 
                  src={currentUser.avatar} 
                  alt={currentUser.username}
                  size="sm"
                />
              </Link>
              
              {/* Menu Button */}
              <button
                onClick={() => setShowMenu(!showMenu)}
                className="ml-1"
                aria-label="Menu"
                data-testid="button-menu"
              >
                <MoreIcon size={24} className="text-foreground" />
              </button>

              {/* Dropdown Menu */}
              {showMenu && (
                <div className="absolute top-full right-0 mt-2 w-48 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg shadow-lg z-50" data-testid="dropdown-menu">
                  <Link href={`/profile/${currentUser.username}`} className="block w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 text-sm" data-testid="menu-profile">
                    Profile
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="block w-full text-left px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-800 text-sm text-red-600 dark:text-red-400 border-t border-gray-200 dark:border-gray-700"
                    data-testid="button-logout"
                  >
                    Log out
                  </button>
                </div>
              )}
            </div>
          )}

          {/* Mobile Profile Avatar (visible on mobile) */}
          {currentUser && (
            <Link href={`/profile/${currentUser.username}`} className="md:hidden" data-testid="link-profile-mobile">
              <Avatar 
                src={currentUser.avatar} 
                alt={currentUser.username}
                size="sm"
              />
            </Link>
          )}
        </div>
      </div>

      {/* Instagram-style font */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Grand+Hotel&display=swap');
        h1 {
          font-family: 'Grand Hotel', cursive !important;
        }
      `}</style>
    </header>
  );
}
