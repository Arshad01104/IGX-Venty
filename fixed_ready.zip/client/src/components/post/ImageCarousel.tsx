import { useState, useRef, useCallback } from "react";
import { cn } from "@/lib/utils";
import { ChevronLeftIcon, ChevronRightIcon } from "@/components/icons/InstagramIcons";

interface ImageCarouselProps {
  images: string[];
  onDoubleTap?: () => void;
}

export function ImageCarousel({ images, onDoubleTap }: ImageCarouselProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const lastTapRef = useRef<number>(0);
  const containerRef = useRef<HTMLDivElement>(null);
  const touchStartRef = useRef<number>(0);
  const touchEndRef = useRef<number>(0);

  const handleDoubleTap = useCallback(() => {
    const now = Date.now();
    const DOUBLE_TAP_DELAY = 300;
    
    if (now - lastTapRef.current < DOUBLE_TAP_DELAY) {
      onDoubleTap?.();
    }
    lastTapRef.current = now;
  }, [onDoubleTap]);

  const goToPrevious = useCallback(() => {
    setCurrentIndex(prev => Math.max(0, prev - 1));
  }, []);

  const goToNext = useCallback(() => {
    setCurrentIndex(prev => Math.min(images.length - 1, prev + 1));
  }, [images.length]);

  const handleTouchStart = useCallback((e: React.TouchEvent) => {
    touchStartRef.current = e.targetTouches[0].clientX;
  }, []);

  const handleTouchMove = useCallback((e: React.TouchEvent) => {
    touchEndRef.current = e.targetTouches[0].clientX;
  }, []);

  const handleTouchEnd = useCallback(() => {
    const diff = touchStartRef.current - touchEndRef.current;
    const threshold = 50;

    if (diff > threshold) {
      goToNext();
    } else if (diff < -threshold) {
      goToPrevious();
    }
  }, [goToNext, goToPrevious]);

  if (images.length === 0) {
    return (
      <div className="aspect-square bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
        <p className="text-gray-500">No image</p>
      </div>
    );
  }

  return (
    <div 
      ref={containerRef}
      className="relative aspect-square bg-black overflow-hidden"
      onClick={handleDoubleTap}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
      data-testid="image-carousel"
    >
      {/* Images */}
      <div 
        className="flex h-full transition-transform duration-300 ease-out"
        style={{ transform: `translateX(-${currentIndex * 100}%)` }}
      >
        {images.map((image, index) => (
          <div key={index} className="w-full h-full flex-shrink-0">
            <img
              src={image}
              alt={`Post image ${index + 1}`}
              className="w-full h-full object-cover"
              loading={index === 0 ? "eager" : "lazy"}
              draggable={false}
            />
          </div>
        ))}
      </div>

      {/* Navigation Arrows (only on desktop and multiple images) */}
      {images.length > 1 && (
        <>
          {currentIndex > 0 && (
            <button
              onClick={(e) => { e.stopPropagation(); goToPrevious(); }}
              className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/90 dark:bg-gray-800/90 flex items-center justify-center shadow-lg hover:bg-white transition-colors hidden md:flex"
              aria-label="Previous image"
              data-testid="carousel-prev"
            >
              <ChevronLeftIcon size={20} className="text-gray-800 dark:text-white" />
            </button>
          )}
          {currentIndex < images.length - 1 && (
            <button
              onClick={(e) => { e.stopPropagation(); goToNext(); }}
              className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full bg-white/90 dark:bg-gray-800/90 flex items-center justify-center shadow-lg hover:bg-white transition-colors hidden md:flex"
              aria-label="Next image"
              data-testid="carousel-next"
            >
              <ChevronRightIcon size={20} className="text-gray-800 dark:text-white" />
            </button>
          )}
        </>
      )}

      {/* Page Indicators */}
      {images.length > 1 && (
        <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1" data-testid="carousel-indicators">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={(e) => { e.stopPropagation(); setCurrentIndex(index); }}
              className={cn(
                "w-1.5 h-1.5 rounded-full transition-all",
                index === currentIndex
                  ? "bg-blue-500 w-2"
                  : "bg-white/60"
              )}
              aria-label={`Go to image ${index + 1}`}
            />
          ))}
        </div>
      )}

      {/* Image Counter (top right) */}
      {images.length > 1 && (
        <div 
          className="absolute top-4 right-4 px-3 py-1 rounded-full bg-black/70 text-white text-xs font-medium"
          data-testid="carousel-counter"
        >
          {currentIndex + 1}/{images.length}
        </div>
      )}
    </div>
  );
}
