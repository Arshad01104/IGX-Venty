import { cn } from "@/lib/utils";
import { HeartIcon } from "@/components/icons/InstagramIcons";

interface HeartAnimationProps {
  show: boolean;
}

export function HeartAnimation({ show }: HeartAnimationProps) {
  return (
    <div 
      className={cn(
        "absolute inset-0 flex items-center justify-center pointer-events-none",
        "transition-opacity duration-300",
        show ? "opacity-100" : "opacity-0"
      )}
    >
      <HeartIcon 
        size={80} 
        filled 
        className={cn(
          "text-white drop-shadow-lg",
          show && "animate-heart-pop"
        )}
      />
      <style>{`
        @keyframes heart-pop {
          0% {
            transform: scale(0);
            opacity: 0;
          }
          50% {
            transform: scale(1.2);
            opacity: 1;
          }
          100% {
            transform: scale(1);
            opacity: 0;
          }
        }
        .animate-heart-pop {
          animation: heart-pop 1s ease-out forwards;
        }
      `}</style>
    </div>
  );
}
