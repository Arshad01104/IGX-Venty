import { useState } from "react";
import { useApp } from "@/context/AppContext";
import { StoryRing, StoryRingSkeleton, AddStoryButton } from "./StoryRing";
import { StoryViewer } from "./StoryViewer";
import { demoUsers } from "@/data/seedData";
import type { User, Story } from "@shared/schema";

interface StoriesRowProps {
  isLoading?: boolean;
}

export function StoriesRow({ isLoading = false }: StoriesRowProps) {
  const { currentUser, stories, getStoriesByUserId } = useApp();
  const [viewerOpen, setViewerOpen] = useState(false);
  const [selectedUserIndex, setSelectedUserIndex] = useState(0);

  const usersWithStories = demoUsers.filter(user => 
    stories.some(story => story.userId === user.id)
  );

  const handleStoryClick = (userIndex: number) => {
    setSelectedUserIndex(userIndex);
    setViewerOpen(true);
  };

  const handleCloseViewer = () => {
    setViewerOpen(false);
  };

  const handleNextUser = () => {
    if (selectedUserIndex < usersWithStories.length - 1) {
      setSelectedUserIndex(prev => prev + 1);
    } else {
      setViewerOpen(false);
    }
  };

  const handlePrevUser = () => {
    if (selectedUserIndex > 0) {
      setSelectedUserIndex(prev => prev - 1);
    }
  };

  if (isLoading) {
    return (
      <div className="border-b border-gray-200 dark:border-gray-800 py-4 px-3">
        <div className="flex gap-4 overflow-x-auto scrollbar-hide">
          {Array.from({ length: 6 }).map((_, i) => (
            <StoryRingSkeleton key={i} />
          ))}
        </div>
      </div>
    );
  }

  return (
    <>
      <div 
        className="border-b border-gray-200 dark:border-gray-800 py-4 px-3"
        data-testid="stories-row"
      >
        <div className="flex gap-4 overflow-x-auto scrollbar-hide">
          {/* Add Story Button */}
          {currentUser && (
            <AddStoryButton 
              currentUser={currentUser}
              onClick={() => {}}
            />
          )}

          {/* User Stories */}
          {usersWithStories.map((user, index) => (
            <StoryRing
              key={user.id}
              user={user}
              stories={getStoriesByUserId(user.id)}
              onClick={() => handleStoryClick(index)}
            />
          ))}
        </div>
      </div>

      {/* Story Viewer Modal */}
      {viewerOpen && usersWithStories[selectedUserIndex] && (
        <StoryViewer
          user={usersWithStories[selectedUserIndex]}
          stories={getStoriesByUserId(usersWithStories[selectedUserIndex].id)}
          onClose={handleCloseViewer}
          onNextUser={handleNextUser}
          onPrevUser={handlePrevUser}
          hasNextUser={selectedUserIndex < usersWithStories.length - 1}
          hasPrevUser={selectedUserIndex > 0}
        />
      )}

      <style>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </>
  );
}
