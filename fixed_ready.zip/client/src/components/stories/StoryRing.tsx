import { cn } from "@/lib/utils";
import type { User, Story } from "@shared/schema";

interface StoryRingProps {
  user: User;
  stories: Story[];
  onClick?: () => void;
  showUsername?: boolean;
  size?: "sm" | "md" | "lg";
}

const sizeConfig = {
  sm: {
    ring: "h-14 w-14",
    avatar: "h-12 w-12",
    padding: "p-[2px]",
    text: "text-[10px]",
    maxWidth: "max-w-[56px]",
  },
  md: {
    ring: "h-16 w-16",
    avatar: "h-14 w-14",
    padding: "p-[2px]",
    text: "text-xs",
    maxWidth: "max-w-[64px]",
  },
  lg: {
    ring: "h-20 w-20",
    avatar: "h-[72px] w-[72px]",
    padding: "p-[3px]",
    text: "text-xs",
    maxWidth: "max-w-[80px]",
  },
};

export function StoryRing({ 
  user, 
  stories, 
  onClick, 
  showUsername = true,
  size = "md" 
}: StoryRingProps) {
  const hasUnreadStories = stories.some(story => !story.isViewed);
  const hasStories = stories.length > 0;
  const config = sizeConfig[size];

  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1 flex-shrink-0"
      data-testid={`story-ring-${user.id}`}
    >
      {/* Story Ring */}
      <div
        className={cn(
          "rounded-full",
          config.ring,
          config.padding,
          hasStories
            ? hasUnreadStories
              ? "bg-gradient-to-tr from-yellow-400 via-red-500 to-purple-600"
              : "bg-gray-300 dark:bg-gray-600"
            : "bg-transparent"
        )}
      >
        <div className={cn(
          "rounded-full bg-white dark:bg-gray-950 p-[2px]",
          config.avatar
        )}>
          <img
            src={user.avatar}
            alt={user.username}
            className={cn(
              "rounded-full object-cover w-full h-full"
            )}
            loading="lazy"
          />
        </div>
      </div>

      {/* Username */}
      {showUsername && (
        <span 
          className={cn(
            "text-foreground truncate w-full text-center",
            config.text,
            config.maxWidth
          )}
        >
          {user.username}
        </span>
      )}
    </button>
  );
}

export function StoryRingSkeleton({ size = "md" }: { size?: "sm" | "md" | "lg" }) {
  const config = sizeConfig[size];
  
  return (
    <div className="flex flex-col items-center gap-1 flex-shrink-0 animate-pulse">
      <div className={cn("rounded-full bg-gray-200 dark:bg-gray-700", config.ring)} />
      <div className="h-3 w-12 bg-gray-200 dark:bg-gray-700 rounded" />
    </div>
  );
}

export function AddStoryButton({ 
  currentUser,
  onClick 
}: { 
  currentUser: User;
  onClick?: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className="flex flex-col items-center gap-1 flex-shrink-0"
      data-testid="add-story-button"
    >
      <div className="relative h-16 w-16">
        <div className="h-16 w-16 rounded-full bg-gray-100 dark:bg-gray-800 p-[2px]">
          <img
            src={currentUser.avatar}
            alt="Your story"
            className="rounded-full object-cover w-full h-full"
          />
        </div>
        <div className="absolute bottom-0 right-0 w-5 h-5 rounded-full bg-blue-500 border-2 border-white dark:border-gray-950 flex items-center justify-center">
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="3">
            <line x1="12" y1="5" x2="12" y2="19" />
            <line x1="5" y1="12" x2="19" y2="12" />
          </svg>
        </div>
      </div>
      <span className="text-xs text-foreground">Your story</span>
    </button>
  );
}
