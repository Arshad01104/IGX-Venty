import { useState, useEffect, useCallback, useRef } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { StoriesRow } from "@/components/stories/StoriesRow";
import { PostCard, PostCardSkeleton } from "@/components/post/PostCard";
import { useApp } from "@/context/AppContext";
import { query, collection, orderBy, limit, getDocs, startAfter, Query, DocumentSnapshot } from "firebase/firestore";
import { db } from "@/services/firebase";
import type { Post } from "@shared/schema";

const POSTS_PER_PAGE = 3;

export default function Home() {
  const { posts, loadingPosts, getUserById } = useApp();
  const [displayedPosts, setDisplayedPosts] = useState(posts.slice(0, POSTS_PER_PAGE));
  const [hasMore, setHasMore] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [lastDoc, setLastDoc] = useState<DocumentSnapshot | null>(null);
  const loaderRef = useRef<HTMLDivElement>(null);
  const [userCache, setUserCache] = useState<Record<string, any>>({});

  useEffect(() => {
    setDisplayedPosts(posts.slice(0, POSTS_PER_PAGE));
    if (posts.length < POSTS_PER_PAGE) {
      setHasMore(false);
    }
  }, [posts]);

  const loadMore = useCallback(async () => {
    if (loadingMore || !hasMore) return;
    
    setLoadingMore(true);
    
    try {
      let q: Query;
      
      if (lastDoc) {
        q = query(
          collection(db, "posts"),
          orderBy("timestamp", "desc"),
          startAfter(lastDoc),
          limit(POSTS_PER_PAGE)
        );
      } else {
        q = query(
          collection(db, "posts"),
          orderBy("timestamp", "desc"),
          limit(POSTS_PER_PAGE * 2)
        );
      }
      
      const snapshot = await getDocs(q);
      
      if (snapshot.docs.length === 0) {
        setHasMore(false);
      } else {
        const newPosts = snapshot.docs.map(doc => ({
          ...doc.data(),
          id: doc.id,
        })) as Post[];
        
        setDisplayedPosts(prev => [...prev, ...newPosts]);
        setLastDoc(snapshot.docs[snapshot.docs.length - 1]);
      }
    } catch (error) {
      console.error("Error loading more posts:", error);
    } finally {
      setLoadingMore(false);
    }
  }, [lastDoc, hasMore, loadingMore]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loadingMore && !loadingPosts) {
          loadMore();
        }
      },
      { rootMargin: "200px" }
    );

    if (loaderRef.current) {
      observer.observe(loaderRef.current);
    }

    return () => observer.disconnect();
  }, [hasMore, loadMore, loadingMore, loadingPosts]);

  const handlePostLoad = async (post: Post) => {
    if (!userCache[post.userId]) {
      const user = await getUserById(post.userId);
      if (user) {
        setUserCache(prev => ({ ...prev, [post.userId]: user }));
      }
    }
  };

  return (
    <MainLayout>
      <div data-testid="home-page">
        {/* Stories Row */}
        <StoriesRow isLoading={loadingPosts} />

        {/* Feed */}
        <div className="divide-y divide-gray-200 dark:divide-gray-800">
          {loadingPosts ? (
            Array.from({ length: 3 }).map((_, i) => (
              <PostCardSkeleton key={i} />
            ))
          ) : displayedPosts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16">
              <p className="text-gray-500">No posts yet. Follow users to see their posts!</p>
            </div>
          ) : (
            displayedPosts.map((post) => {
              const user = userCache[post.userId];
              
              if (!user) {
                handlePostLoad(post);
                return <PostCardSkeleton key={post.id} />;
              }
              
              return (
                <PostCard 
                  key={post.id} 
                  post={post} 
                  user={user}
                />
              );
            })
          )}
        </div>

        {/* Infinite Scroll Loader */}
        <div ref={loaderRef} className="py-8">
          {loadingMore && (
            <div className="flex justify-center">
              <div className="w-6 h-6 border-2 border-gray-300 border-t-gray-600 rounded-full animate-spin" />
            </div>
          )}
          {!hasMore && displayedPosts.length > 0 && (
            <p className="text-center text-gray-500 text-sm">
              You're all caught up!
            </p>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
