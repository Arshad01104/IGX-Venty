import { useState, useRef } from "react";
import { useLocation } from "wouter";
import { MainLayout } from "@/components/layout/MainLayout";
import { Button } from "@/components/ui/button";
import { ChevronLeftIcon, CloseIcon } from "@/components/icons/InstagramIcons";
import { useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { collection, addDoc, serverTimestamp } from "firebase/firestore";
import { ref, uploadBytes, getDownloadURL } from "firebase/storage";
import { db, storage } from "@/services/firebase";

export default function CreatePost() {
  const [, setLocation] = useLocation();
  const { currentUser } = useApp();
  const { user: authUser } = useAuth();
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previews, setPreviews] = useState<string[]>([]);
  const [caption, setCaption] = useState("");
  const [location, setPostLocation] = useState("");
  const [step, setStep] = useState<"select" | "edit">("select");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    setSelectedFiles(files);
    
    const newPreviews = files.map(file => URL.createObjectURL(file));
    setPreviews(newPreviews);
    setStep("edit");
  };

  const handleRemoveImage = (index: number) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index);
    const newPreviews = previews.filter((_, i) => i !== index);
    
    URL.revokeObjectURL(previews[index]);
    
    setSelectedFiles(newFiles);
    setPreviews(newPreviews);
    
    if (newFiles.length === 0) {
      setStep("select");
    }
  };

  const handleShare = async () => {
    if (!authUser || !selectedFiles.length) return;

    setUploading(true);
    try {
      const imageUrls: string[] = [];

      // Upload images to Firebase Storage
      for (const file of selectedFiles) {
        const storageRef = ref(storage, `posts/${authUser.uid}/${Date.now()}-${file.name}`);
        await uploadBytes(storageRef, file);
        const downloadURL = await getDownloadURL(storageRef);
        imageUrls.push(downloadURL);
      }

      // Create post document in Firestore
      await addDoc(collection(db, "posts"), {
        userId: authUser.uid,
        images: imageUrls,
        caption,
        location,
        likesCount: 0,
        commentsCount: 0,
        timestamp: serverTimestamp(),
        isVideo: false,
      });

      setLocation("/");
    } catch (error) {
      console.error("Error sharing post:", error);
      alert("Failed to share post. Please try again.");
    } finally {
      setUploading(false);
    }
  };

  const handleBack = () => {
    if (step === "edit") {
      setStep("select");
      setSelectedFiles([]);
      setPreviews([]);
    } else {
      setLocation("/");
    }
  };

  return (
    <MainLayout hideBottomNav>
      <div className="min-h-screen bg-white dark:bg-gray-950" data-testid="create-post-page">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center justify-between h-14 px-4">
            <button onClick={handleBack} aria-label="Go back" data-testid="create-back-button">
              <ChevronLeftIcon size={28} className="text-foreground" />
            </button>
            <h1 className="font-semibold text-base">New post</h1>
            {step === "edit" && (
              <Button 
                variant="ghost" 
                className="text-blue-500 font-semibold"
                onClick={handleShare}
                disabled={uploading}
                data-testid="create-share-button"
              >
                {uploading ? "Sharing..." : "Share"}
              </Button>
            )}
            {step === "select" && <div className="w-14" />}
          </div>
        </header>

        {step === "select" ? (
          /* File Selection */
          <div className="flex flex-col items-center justify-center h-[calc(100vh-56px)] p-6">
            <div className="text-center mb-8">
              <svg width="96" height="96" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="mx-auto mb-4 text-gray-400">
                <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                <circle cx="8.5" cy="8.5" r="1.5"/>
                <polyline points="21 15 16 10 5 21"/>
              </svg>
              <h2 className="text-xl font-light mb-2">Create new post</h2>
              <p className="text-gray-500 text-sm">Share photos and videos with your followers</p>
            </div>
            
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              multiple
              onChange={handleFileSelect}
              className="hidden"
              data-testid="create-file-input"
            />
            
            <Button
              onClick={() => fileInputRef.current?.click()}
              className="bg-blue-500 hover:bg-blue-600 text-white px-8"
              data-testid="create-select-button"
            >
              Select from device
            </Button>
          </div>
        ) : (
          /* Edit Post */
          <div className="pb-20">
            {/* Image Preview */}
            <div className="relative aspect-square bg-gray-100 dark:bg-gray-800">
              {previews.length > 0 && (
                <div className="relative w-full h-full">
                  <img
                    src={previews[0]}
                    alt="Preview"
                    className="w-full h-full object-cover"
                  />
                  {previews.length > 1 && (
                    <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1">
                      {previews.map((_, index) => (
                        <div
                          key={index}
                          className={`w-1.5 h-1.5 rounded-full ${index === 0 ? 'bg-blue-500' : 'bg-white/60'}`}
                        />
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Selected Images Thumbnails */}
            {previews.length > 1 && (
              <div className="flex gap-2 p-3 overflow-x-auto">
                {previews.map((preview, index) => (
                  <div key={index} className="relative flex-shrink-0">
                    <img
                      src={preview}
                      alt={`Preview ${index + 1}`}
                      className="w-16 h-16 object-cover rounded-md"
                    />
                    <button
                      onClick={() => handleRemoveImage(index)}
                      className="absolute -top-1 -right-1 w-5 h-5 bg-gray-800 rounded-full flex items-center justify-center"
                      aria-label="Remove image"
                    >
                      <CloseIcon size={12} className="text-white" />
                    </button>
                  </div>
                ))}
              </div>
            )}

            {/* Caption Input */}
            <div className="p-4 border-b border-gray-200 dark:border-gray-800">
              <div className="flex gap-3">
                {currentUser && (
                  <img
                    src={currentUser.avatar}
                    alt={currentUser.username}
                    className="w-10 h-10 rounded-full flex-shrink-0"
                  />
                )}
                <textarea
                  placeholder="Write a caption..."
                  value={caption}
                  onChange={(e) => setCaption(e.target.value)}
                  className="flex-1 resize-none bg-transparent outline-none text-sm min-h-[80px]"
                  data-testid="create-caption-input"
                />
              </div>
            </div>

            {/* Add Location */}
            <button 
              className="w-full flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800"
              data-testid="create-location-button"
            >
              <span className="text-sm">Add location</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>

            {/* Tag People */}
            <button 
              className="w-full flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-800"
              data-testid="create-tag-button"
            >
              <span className="text-sm">Tag people</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>

            {/* Advanced Settings */}
            <button 
              className="w-full flex items-center justify-between p-4"
              data-testid="create-settings-button"
            >
              <span className="text-sm">Advanced settings</span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <polyline points="9 18 15 12 9 6"/>
              </svg>
            </button>
          </div>
        )}
      </div>
    </MainLayout>
  );
}
