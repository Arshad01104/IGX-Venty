import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { SearchIcon, ReelsIcon } from "@/components/icons/InstagramIcons";
import { demoPosts, demoUsers } from "@/data/seedData";
import { cn } from "@/lib/utils";

export default function Explore() {
  const [searchQuery, setSearchQuery] = useState("");
  const [isSearchFocused, setIsSearchFocused] = useState(false);

  const filteredUsers = searchQuery
    ? demoUsers.filter(user => 
        user.username.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.displayName.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : [];

  return (
    <MainLayout>
      <div className="min-h-screen" data-testid="explore-page">
        {/* Search Bar */}
        <div className="sticky top-14 z-30 bg-white dark:bg-gray-950 p-3">
          <div className="relative">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <SearchIcon size={16} className="text-gray-400" />
            </div>
            <input
              type="search"
              placeholder="Search"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              onFocus={() => setIsSearchFocused(true)}
              onBlur={() => setTimeout(() => setIsSearchFocused(false), 200)}
              className="w-full h-10 pl-10 pr-4 rounded-lg bg-gray-100 dark:bg-gray-800 text-sm placeholder:text-gray-500 focus:outline-none"
              data-testid="explore-search-input"
            />
          </div>

          {/* Search Results */}
          {isSearchFocused && searchQuery && (
            <div className="absolute left-3 right-3 mt-2 bg-white dark:bg-gray-900 rounded-lg shadow-lg border border-gray-200 dark:border-gray-700 overflow-hidden z-50">
              {filteredUsers.length > 0 ? (
                filteredUsers.map(user => (
                  <a
                    key={user.id}
                    href={`/profile/${user.username}`}
                    className="flex items-center gap-3 p-3 hover:bg-gray-50 dark:hover:bg-gray-800"
                    data-testid={`search-result-${user.id}`}
                  >
                    <img
                      src={user.avatar}
                      alt={user.username}
                      className="w-10 h-10 rounded-full"
                    />
                    <div>
                      <p className="font-semibold text-sm">{user.username}</p>
                      <p className="text-sm text-gray-500">{user.displayName}</p>
                    </div>
                  </a>
                ))
              ) : (
                <div className="p-4 text-center text-gray-500 text-sm">
                  No results found
                </div>
              )}
            </div>
          )}
        </div>

        {/* Explore Grid */}
        <div className="grid grid-cols-3 gap-0.5" data-testid="explore-grid">
          {demoPosts.map((post, index) => {
            const isLarge = index % 10 === 0 || index % 10 === 5;
            
            return (
              <button 
                key={post.id}
                className={cn(
                  "relative aspect-square group",
                  isLarge && "col-span-2 row-span-2"
                )}
                data-testid={`explore-post-${post.id}`}
              >
                <img
                  src={post.images[0]}
                  alt="Explore post"
                  className="w-full h-full object-cover"
                  loading="lazy"
                />
                {post.images.length > 1 && (
                  <div className="absolute top-2 right-2">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="white" className="drop-shadow-lg">
                      <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H5V5h12v14z"/>
                    </svg>
                  </div>
                )}
                {post.isVideo && (
                  <div className="absolute top-2 right-2">
                    <ReelsIcon size={16} className="text-white drop-shadow-lg" />
                  </div>
                )}
                {/* Hover overlay */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-6 text-white">
                  <span className="flex items-center gap-1 font-semibold">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                    </svg>
                    {post.likesCount}
                  </span>
                  <span className="flex items-center gap-1 font-semibold">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                      <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
                    </svg>
                    {post.commentsCount}
                  </span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </MainLayout>
  );
}
