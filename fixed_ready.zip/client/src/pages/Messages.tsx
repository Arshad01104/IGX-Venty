import { useState } from "react";
import { MainLayout } from "@/components/layout/MainLayout";
import { Avatar } from "@/components/ui/Avatar";
import { ChevronLeftIcon, CreateIcon } from "@/components/icons/InstagramIcons";
import { useApp } from "@/context/AppContext";
import { demoUsers } from "@/data/seedData";
import { Link } from "wouter";

interface Conversation {
  userId: string;
  lastMessage: string;
  timestamp: string;
  unread: boolean;
}

const demoConversations: Conversation[] = [
  {
    userId: "user_2",
    lastMessage: "That recipe looks amazing! Can you share it?",
    timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
    unread: true,
  },
  {
    userId: "user_3",
    lastMessage: "Thanks for the workout tips!",
    timestamp: new Date(Date.now() - 3 * 60 * 60 * 1000).toISOString(),
    unread: false,
  },
];

export default function Messages() {
  const { currentUser } = useApp();
  const [searchQuery, setSearchQuery] = useState("");

  const filteredConversations = searchQuery
    ? demoConversations.filter(conv => {
        const user = demoUsers.find(u => u.id === conv.userId);
        return user?.username.toLowerCase().includes(searchQuery.toLowerCase());
      })
    : demoConversations;

  const formatTime = (timestamp: string) => {
    const diff = Date.now() - new Date(timestamp).getTime();
    const hours = Math.floor(diff / (60 * 60 * 1000));
    
    if (hours < 1) return "now";
    if (hours < 24) return `${hours}h`;
    const days = Math.floor(hours / 24);
    if (days < 7) return `${days}d`;
    return `${Math.floor(days / 7)}w`;
  };

  return (
    <MainLayout hideBottomNav>
      <div className="min-h-screen" data-testid="messages-page">
        {/* Header */}
        <header className="sticky top-0 z-40 bg-white dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800">
          <div className="flex items-center justify-between h-14 px-4">
            <Link href="/">
              <ChevronLeftIcon size={28} className="text-foreground" />
            </Link>
            <div className="flex items-center gap-1">
              <span className="font-semibold">{currentUser?.username}</span>
              <svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor">
                <path d="M7 10l5 5 5-5H7z"/>
              </svg>
            </div>
            <button aria-label="New message" data-testid="new-message-button">
              <CreateIcon size={24} className="text-foreground" />
            </button>
          </div>
        </header>

        {/* Search */}
        <div className="p-3">
          <input
            type="search"
            placeholder="Search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full h-9 px-4 rounded-lg bg-gray-100 dark:bg-gray-800 text-sm placeholder:text-gray-500 focus:outline-none"
            data-testid="messages-search"
          />
        </div>

        {/* Messages Label */}
        <div className="px-4 py-2">
          <h2 className="font-semibold text-base">Messages</h2>
        </div>

        {/* Conversations List */}
        <div className="divide-y divide-gray-100 dark:divide-gray-800">
          {filteredConversations.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16">
              <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="text-gray-300 mb-4">
                <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
              </svg>
              <p className="text-gray-500 text-sm">No messages yet</p>
            </div>
          ) : (
            filteredConversations.map(conversation => {
              const user = demoUsers.find(u => u.id === conversation.userId);
              if (!user) return null;

              return (
                <button
                  key={conversation.userId}
                  className="w-full flex items-center gap-3 p-4 hover:bg-gray-50 dark:hover:bg-gray-900"
                  data-testid={`conversation-${conversation.userId}`}
                >
                  <Avatar src={user.avatar} alt={user.username} size="lg" />
                  
                  <div className="flex-1 min-w-0 text-left">
                    <div className="flex items-center gap-2">
                      <span className={`text-sm ${conversation.unread ? 'font-semibold' : ''}`}>
                        {user.username}
                      </span>
                    </div>
                    <div className="flex items-center gap-1">
                      <p className={`text-sm truncate ${conversation.unread ? 'text-foreground font-medium' : 'text-gray-500'}`}>
                        {conversation.lastMessage}
                      </p>
                      <span className="text-gray-500 text-sm flex-shrink-0">
                        · {formatTime(conversation.timestamp)}
                      </span>
                    </div>
                  </div>

                  {conversation.unread && (
                    <div className="w-2 h-2 rounded-full bg-blue-500 flex-shrink-0" />
                  )}
                </button>
              );
            })
          )}
        </div>
      </div>
    </MainLayout>
  );
}
