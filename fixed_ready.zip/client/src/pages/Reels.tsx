import { useState, useRef, useEffect, useCallback } from "react";
import { cn } from "@/lib/utils";
import { Avatar } from "@/components/ui/Avatar";
import {
  HeartIcon,
  CommentIcon,
  ShareIcon,
  MoreIcon,
  MusicIcon,
  VolumeIcon,
  PlayIcon,
} from "@/components/icons/InstagramIcons";
import { demoReels, getUserById } from "@/data/seedData";
import type { Reel } from "@shared/schema";

interface ReelPlayerProps {
  reel: Reel;
  isActive: boolean;
  isMuted: boolean;
  onToggleMute: () => void;
}

function ReelPlayer({ reel, isActive, isMuted, onToggleMute }: ReelPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLiked, setIsLiked] = useState(false);
  const [showPauseIcon, setShowPauseIcon] = useState(false);
  
  const user = getUserById(reel.userId);

  useEffect(() => {
    if (!videoRef.current) return;
    
    if (isActive) {
      videoRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      videoRef.current.pause();
      videoRef.current.currentTime = 0;
      setIsPlaying(false);
    }
  }, [isActive]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.muted = isMuted;
    }
  }, [isMuted]);

  const handleVideoClick = () => {
    if (!videoRef.current) return;
    
    if (isPlaying) {
      videoRef.current.pause();
      setIsPlaying(false);
      setShowPauseIcon(true);
      setTimeout(() => setShowPauseIcon(false), 500);
    } else {
      videoRef.current.play();
      setIsPlaying(true);
    }
  };

  const handleDoubleTap = useCallback(() => {
    setIsLiked(true);
  }, []);

  const formatCount = (count: number): string => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(0)}K`;
    return count.toString();
  };

  if (!user) return null;

  return (
    <div 
      className="relative h-screen w-full bg-black snap-start snap-always"
      data-testid={`reel-${reel.id}`}
    >
      {/* Video */}
      <video
        ref={videoRef}
        src={reel.videoUrl}
        poster={reel.thumbnailUrl}
        className="absolute inset-0 w-full h-full object-cover"
        loop
        playsInline
        muted={isMuted}
        onClick={handleVideoClick}
        onDoubleClick={handleDoubleTap}
      />

      {/* Pause Icon Overlay */}
      {showPauseIcon && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <div className="w-20 h-20 rounded-full bg-black/50 flex items-center justify-center">
            <PlayIcon size={40} className="text-white ml-1" />
          </div>
        </div>
      )}

      {/* Gradient Overlays */}
      <div className="absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-black/60 to-transparent pointer-events-none" />
      <div className="absolute inset-x-0 top-0 h-24 bg-gradient-to-b from-black/40 to-transparent pointer-events-none" />

      {/* Right Side Actions */}
      <div className="absolute right-3 bottom-24 flex flex-col items-center gap-5">
        {/* Profile */}
        <button className="relative" data-testid="reel-profile">
          <Avatar src={user.avatar} alt={user.username} size="md" />
          <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 w-5 h-5 rounded-full bg-red-500 border-2 border-black flex items-center justify-center">
            <span className="text-white text-xs font-bold">+</span>
          </div>
        </button>

        {/* Like */}
        <button 
          className="flex flex-col items-center gap-1"
          onClick={() => setIsLiked(!isLiked)}
          data-testid="reel-like"
        >
          <HeartIcon 
            size={28} 
            filled={isLiked}
            className={isLiked ? "text-red-500" : "text-white"} 
          />
          <span className="text-white text-xs font-semibold">
            {formatCount(reel.likesCount + (isLiked ? 1 : 0))}
          </span>
        </button>

        {/* Comment */}
        <button className="flex flex-col items-center gap-1" data-testid="reel-comment">
          <CommentIcon size={28} className="text-white" />
          <span className="text-white text-xs font-semibold">
            {formatCount(reel.commentsCount)}
          </span>
        </button>

        {/* Share */}
        <button className="flex flex-col items-center gap-1" data-testid="reel-share">
          <ShareIcon size={28} className="text-white" />
          <span className="text-white text-xs font-semibold">
            {formatCount(reel.sharesCount)}
          </span>
        </button>

        {/* More */}
        <button data-testid="reel-more">
          <MoreIcon size={24} className="text-white" />
        </button>

        {/* Audio */}
        <button className="w-8 h-8 rounded-md overflow-hidden border-2 border-white">
          <img 
            src={user.avatar} 
            alt="Audio" 
            className="w-full h-full object-cover animate-spin-slow"
          />
        </button>
      </div>

      {/* Bottom Info */}
      <div className="absolute left-3 right-16 bottom-6">
        {/* Username */}
        <div className="flex items-center gap-2 mb-2">
          <span className="text-white font-semibold" data-testid="reel-username">
            {user.username}
          </span>
          <button className="px-3 py-1 border border-white rounded text-white text-xs font-semibold">
            Follow
          </button>
        </div>

        {/* Caption */}
        {reel.caption && (
          <p className="text-white text-sm mb-2 line-clamp-2" data-testid="reel-caption">
            {reel.caption}
          </p>
        )}

        {/* Audio Name */}
        {reel.audioName && (
          <div className="flex items-center gap-2">
            <MusicIcon size={14} className="text-white" />
            <span className="text-white text-xs">{reel.audioName}</span>
          </div>
        )}
      </div>

      {/* Mute Button */}
      <button
        onClick={onToggleMute}
        className="absolute top-16 right-3 w-8 h-8 rounded-full bg-black/50 flex items-center justify-center"
        data-testid="reel-mute"
      >
        <VolumeIcon size={16} muted={isMuted} className="text-white" />
      </button>

      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 3s linear infinite;
        }
      `}</style>
    </div>
  );
}

export default function Reels() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isMuted, setIsMuted] = useState(true);
  const containerRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const scrollTop = container.scrollTop;
      const viewportHeight = container.clientHeight;
      const newIndex = Math.round(scrollTop / viewportHeight);
      setActiveIndex(newIndex);
    };

    container.addEventListener("scroll", handleScroll);
    return () => container.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <div 
      ref={containerRef}
      className="h-screen overflow-y-scroll snap-y snap-mandatory"
      style={{ scrollSnapType: "y mandatory" }}
      data-testid="reels-page"
    >
      {demoReels.map((reel, index) => (
        <ReelPlayer
          key={reel.id}
          reel={reel}
          isActive={index === activeIndex}
          isMuted={isMuted}
          onToggleMute={() => setIsMuted(!isMuted)}
        />
      ))}
    </div>
  );
}
