import { useState, useEffect } from "react";
import { useParams } from "wouter";
import { MainLayout } from "@/components/layout/MainLayout";
import { Avatar } from "@/components/ui/Avatar";
import { Button } from "@/components/ui/button";
import { 
  GridIcon, 
  ReelsIcon, 
  BookmarkIcon,
  VerifiedIcon,
  MoreIcon 
} from "@/components/icons/InstagramIcons";
import { useApp } from "@/context/AppContext";
import { useAuth } from "@/context/AuthContext";
import { collection, query, where, getDocs } from "firebase/firestore";
import { db } from "@/services/firebase";
import type { Post, User } from "@shared/schema";
import { cn } from "@/lib/utils";

type TabType = "posts" | "reels" | "saved";

export default function Profile() {
  const params = useParams<{ username: string }>();
  const { currentUser: appUser } = useApp();
  const { user: authUser } = useAuth();
  const [user, setUser] = useState<User | null>(null);
  const [userPosts, setUserPosts] = useState<Post[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<TabType>("posts");
  
  const isOwnProfile = appUser?.id === user?.id || authUser?.uid === user?.id;

  useEffect(() => {
    const loadUser = async () => {
      try {
        setLoading(true);
        if (!params.username) return;

        // Query user by username
        const usersQuery = query(
          collection(db, "users"),
          where("username", "==", params.username)
        );
        const usersSnapshot = await getDocs(usersQuery);
        
        if (usersSnapshot.empty) {
          setUser(null);
          setUserPosts([]);
          return;
        }

        const userData = usersSnapshot.docs[0].data() as User;
        setUser(userData);

        // Load user's posts
        const postsQuery = query(
          collection(db, "posts"),
          where("userId", "==", userData.id)
        );
        const postsSnapshot = await getDocs(postsQuery);
        const posts = postsSnapshot.docs.map(doc => ({
          ...doc.data(),
          id: doc.id,
        })) as Post[];
        setUserPosts(posts);
      } catch (error) {
        console.error("Error loading profile:", error);
      } finally {
        setLoading(false);
      }
    };

    loadUser();
  }, [params.username]);

  if (loading) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-64">
          <p className="text-gray-500">Loading...</p>
        </div>
      </MainLayout>
    );
  }

  if (!user) {
    return (
      <MainLayout>
        <div className="flex items-center justify-center h-64">
          <p className="text-gray-500">User not found</p>
        </div>
      </MainLayout>
    );
  }

  const formatCount = (count: number): string => {
    if (count >= 1000000) return `${(count / 1000000).toFixed(1)}M`;
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  const tabs = [
    { id: "posts" as const, icon: GridIcon, label: "Posts" },
    { id: "reels" as const, icon: ReelsIcon, label: "Reels" },
    { id: "saved" as const, icon: BookmarkIcon, label: "Saved", ownOnly: true },
  ];

  return (
    <MainLayout>
      <div className="pb-4" data-testid="profile-page">
        {/* Profile Header */}
        <header className="p-4">
          <div className="flex items-start gap-4 mb-4">
            {/* Avatar */}
            <Avatar 
              src={user.avatar} 
              alt={user.username}
              size="xl"
              className="flex-shrink-0"
            />

            {/* Stats */}
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-3">
                <h1 className="text-xl font-normal" data-testid="profile-username">
                  {user.username}
                </h1>
                {user.isVerified && <VerifiedIcon size={18} />}
                <button className="ml-auto p-2">
                  <MoreIcon size={24} className="text-foreground" />
                </button>
              </div>

              <div className="flex gap-4 md:gap-8 text-sm">
                <div className="text-center" data-testid="profile-posts-count">
                  <span className="font-semibold">{formatCount(userPosts.length)}</span>
                  <span className="text-gray-500 ml-1">posts</span>
                </div>
                <button className="text-center" data-testid="profile-followers-count">
                  <span className="font-semibold">{formatCount(user.followersCount)}</span>
                  <span className="text-gray-500 ml-1">followers</span>
                </button>
                <button className="text-center" data-testid="profile-following-count">
                  <span className="font-semibold">{formatCount(user.followingCount)}</span>
                  <span className="text-gray-500 ml-1">following</span>
                </button>
              </div>
            </div>
          </div>

          {/* Bio */}
          <div className="mb-4">
            <h2 className="font-semibold text-sm" data-testid="profile-display-name">
              {user.displayName}
            </h2>
            {user.bio && (
              <p className="text-sm whitespace-pre-wrap" data-testid="profile-bio">
                {user.bio}
              </p>
            )}
            {user.website && (
              <a 
                href={`https://${user.website}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-sm text-blue-500 font-semibold"
                data-testid="profile-website"
              >
                {user.website}
              </a>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            {isOwnProfile ? (
              <>
                <Button 
                  variant="secondary" 
                  className="flex-1 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700"
                  data-testid="edit-profile-button"
                >
                  Edit profile
                </Button>
                <Button 
                  variant="secondary"
                  className="flex-1 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700"
                  data-testid="share-profile-button"
                >
                  Share profile
                </Button>
              </>
            ) : (
              <>
                <Button 
                  className="flex-1 bg-blue-500 hover:bg-blue-600 text-white"
                  data-testid="follow-button"
                >
                  Follow
                </Button>
                <Button 
                  variant="secondary"
                  className="flex-1 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700"
                  data-testid="message-button"
                >
                  Message
                </Button>
              </>
            )}
          </div>
        </header>

        {/* Tabs */}
        <div className="border-t border-gray-200 dark:border-gray-800">
          <div className="flex">
            {tabs.map((tab) => {
              if (tab.ownOnly && !isOwnProfile) return null;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={cn(
                    "flex-1 flex items-center justify-center py-3 border-t",
                    activeTab === tab.id
                      ? "border-foreground"
                      : "border-transparent text-gray-400"
                  )}
                  aria-label={tab.label}
                  data-testid={`tab-${tab.id}`}
                >
                  <tab.icon size={24} className={activeTab === tab.id ? "text-foreground" : ""} />
                </button>
              );
            })}
          </div>
        </div>

        {/* Posts Grid */}
        <div className="grid grid-cols-3 gap-0.5" data-testid="posts-grid">
          {activeTab === "posts" && (
            userPosts.length === 0 ? (
              <div className="col-span-3 py-12 text-center text-gray-500">
                <p>No posts yet</p>
              </div>
            ) : (
              userPosts.map((post) => (
                <button 
                  key={post.id}
                  className="aspect-square relative group"
                  data-testid={`grid-post-${post.id}`}
                >
                  <img
                    src={post.images[0]}
                    alt="Post"
                    className="w-full h-full object-cover"
                    loading="lazy"
                  />
                  {post.images.length > 1 && (
                    <div className="absolute top-2 right-2">
                      <svg width="16" height="16" viewBox="0 0 24 24" fill="white" className="drop-shadow-lg">
                        <path d="M19 3H5c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V5c0-1.1-.9-2-2-2zm-2 16H5V5h12v14z"/>
                      </svg>
                    </div>
                  )}
                  {post.isVideo && (
                    <div className="absolute top-2 right-2">
                      <ReelsIcon size={16} className="text-white drop-shadow-lg" />
                    </div>
                  )}
                  {/* Hover overlay */}
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-6 text-white">
                    <span className="flex items-center gap-1 font-semibold">
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
                      </svg>
                      {post.likesCount}
                    </span>
                    <span className="flex items-center gap-1 font-semibold">
                      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>
                      </svg>
                      {post.commentsCount}
                    </span>
                  </div>
                </button>
              ))
            )
          )}
          
          {activeTab === "reels" && (
            <div className="col-span-3 py-12 text-center text-gray-500">
              <ReelsIcon size={48} className="mx-auto mb-2 opacity-50" />
              <p>No reels yet</p>
            </div>
          )}
          
          {activeTab === "saved" && (
            <div className="col-span-3 py-12 text-center text-gray-500">
              <BookmarkIcon size={48} className="mx-auto mb-2 opacity-50" />
              <p>No saved posts</p>
            </div>
          )}
        </div>
      </div>
    </MainLayout>
  );
}
