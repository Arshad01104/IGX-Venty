import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useAuth } from "@/context/AuthContext";

export default function Signup() {
  const [, setLocation] = useLocation();
  const { signup, loginWithGoogle, isLoading } = useAuth();
  const [email, setEmail] = useState("");
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");

    if (password.length < 6) {
      setError("Password must be at least 6 characters");
      return;
    }

    try {
      await signup(email, password, username);
      setTimeout(() => setLocation("/"), 500);
    } catch (err: any) {
      setError(err?.message || "Failed to create account");
    }
  };

  const handleGoogleSignup = async () => {
    try {
      await loginWithGoogle();
      setTimeout(() => setLocation("/"), 500);
    } catch (err: any) {
      setError(err?.message || "Failed to sign up with Google");
    }
  };

  const isFormValid = email && fullName && username && password.length >= 6;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-950 px-4" data-testid="signup-page">
      <div className="w-full max-w-[350px]">
        {/* Main Card */}
        <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 p-10 mb-4">
          <h1 
            className="text-4xl text-center mb-4"
            style={{ fontFamily: "'Grand Hotel', cursive" }}
          >
            IGX
          </h1>

          <p className="text-center text-gray-500 font-semibold text-base mb-5">
            Sign up to see photos and videos from your friends.
          </p>

          <button
            onClick={handleGoogleSignup}
            className="w-full flex items-center justify-center gap-2 bg-blue-500 hover:bg-blue-600 text-white font-semibold text-sm py-2 rounded-lg mb-4"
            disabled={isLoading}
            data-testid="signup-google"
          >
            <svg width="16" height="16" viewBox="0 0 24 24" fill="white">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            Log in with Google
          </button>

          <div className="flex items-center gap-4 my-5">
            <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700" />
            <span className="text-sm text-gray-500 font-semibold">OR</span>
            <div className="flex-1 h-px bg-gray-200 dark:bg-gray-700" />
          </div>

          <form onSubmit={handleSubmit} className="space-y-3">
            <Input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-sm"
              data-testid="signup-email"
              required
            />
            <Input
              type="text"
              placeholder="Full Name"
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              className="bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-sm"
              data-testid="signup-fullname"
              required
            />
            <Input
              type="text"
              placeholder="Username"
              value={username}
              onChange={(e) => setUsername(e.target.value.toLowerCase().replace(/[^a-z0-9._]/g, ""))}
              className="bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-sm"
              data-testid="signup-username"
              required
            />
            <Input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="bg-gray-50 dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-sm"
              data-testid="signup-password"
              required
            />

            {error && (
              <p className="text-red-500 text-sm text-center" data-testid="signup-error">
                {error}
              </p>
            )}

            <p className="text-xs text-gray-500 text-center">
              People who use our service may have uploaded your contact information to IGX.{" "}
              <a href="#" className="text-blue-900 dark:text-blue-400">Learn More</a>
            </p>

            <p className="text-xs text-gray-500 text-center">
              By signing up, you agree to our{" "}
              <a href="#" className="text-blue-900 dark:text-blue-400">Terms</a>,{" "}
              <a href="#" className="text-blue-900 dark:text-blue-400">Privacy Policy</a> and{" "}
              <a href="#" className="text-blue-900 dark:text-blue-400">Cookies Policy</a>.
            </p>

            <Button 
              type="submit" 
              className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold disabled:opacity-50"
              disabled={isLoading || !isFormValid}
              data-testid="signup-submit"
            >
              {isLoading ? "Signing up..." : "Sign up"}
            </Button>
          </form>
        </div>

        {/* Login link */}
        <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 p-5 text-center">
          <p className="text-sm">
            Have an account?{" "}
            <Link href="/login" className="text-blue-500 font-semibold" data-testid="login-link">
              Log in
            </Link>
          </p>
        </div>

        {/* App download */}
        <div className="text-center mt-5">
          <p className="text-sm mb-4">Get the app.</p>
          <div className="flex justify-center gap-2">
            <img 
              src="https://static.cdninstagram.com/rsrc.php/v3/yz/r/c5Rp7Ym-Klz.png" 
              alt="Download on App Store" 
              className="h-10"
            />
            <img 
              src="https://static.cdninstagram.com/rsrc.php/v3/yu/r/EHY6QnZYdNX.png" 
              alt="Get it on Google Play" 
              className="h-10"
            />
          </div>
        </div>
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Grand+Hotel&display=swap');
      `}</style>
    </div>
  );
}
