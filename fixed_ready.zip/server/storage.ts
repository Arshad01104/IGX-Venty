import { 
  type User, type InsertUser,
  type Post, type InsertPost,
  type Story, type InsertStory,
  type Comment, type InsertComment,
  type Like, type InsertLike,
  type Follow, type InsertFollow,
  type Notification, type InsertNotification,
  type Reel, type InsertReel,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, updates: Partial<User>): Promise<User | undefined>;
  searchUsers(query: string): Promise<User[]>;

  // Posts
  getPost(id: string): Promise<Post | undefined>;
  getPosts(limit: number, offset: number): Promise<Post[]>;
  getPostsByUser(userId: string): Promise<Post[]>;
  createPost(post: InsertPost): Promise<Post>;
  deletePost(id: string): Promise<boolean>;

  // Stories
  getStory(id: string): Promise<Story | undefined>;
  getStoriesByUser(userId: string): Promise<Story[]>;
  getActiveStories(): Promise<Story[]>;
  createStory(story: InsertStory): Promise<Story>;
  markStoryViewed(id: string): Promise<boolean>;

  // Comments
  getCommentsByPost(postId: string): Promise<Comment[]>;
  createComment(comment: InsertComment): Promise<Comment>;
  deleteComment(id: string): Promise<boolean>;

  // Likes
  getLikesByPost(postId: string): Promise<Like[]>;
  createLike(like: InsertLike): Promise<Like>;
  deleteLike(userId: string, postId: string): Promise<boolean>;
  hasUserLikedPost(userId: string, postId: string): Promise<boolean>;

  // Follows
  getFollowers(userId: string): Promise<Follow[]>;
  getFollowing(userId: string): Promise<Follow[]>;
  createFollow(follow: InsertFollow): Promise<Follow>;
  deleteFollow(followerId: string, followingId: string): Promise<boolean>;
  isFollowing(followerId: string, followingId: string): Promise<boolean>;

  // Notifications
  getNotificationsByUser(userId: string): Promise<Notification[]>;
  createNotification(notification: InsertNotification): Promise<Notification>;
  markNotificationRead(id: string): Promise<boolean>;
  markAllNotificationsRead(userId: string): Promise<boolean>;

  // Reels
  getReel(id: string): Promise<Reel | undefined>;
  getReels(limit: number, offset: number): Promise<Reel[]>;
  createReel(reel: InsertReel): Promise<Reel>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private posts: Map<string, Post>;
  private stories: Map<string, Story>;
  private comments: Map<string, Comment>;
  private likes: Map<string, Like>;
  private follows: Map<string, Follow>;
  private notifications: Map<string, Notification>;
  private reels: Map<string, Reel>;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.stories = new Map();
    this.comments = new Map();
    this.likes = new Map();
    this.follows = new Map();
    this.notifications = new Map();
    this.reels = new Map();
  }

  // Users
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...updates };
    this.users.set(id, updated);
    return updated;
  }

  async searchUsers(query: string): Promise<User[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.users.values()).filter(
      user => user.username.toLowerCase().includes(lowerQuery) ||
              user.displayName.toLowerCase().includes(lowerQuery)
    );
  }

  // Posts
  async getPost(id: string): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async getPosts(limit: number, offset: number): Promise<Post[]> {
    const allPosts = Array.from(this.posts.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return allPosts.slice(offset, offset + limit);
  }

  async getPostsByUser(userId: string): Promise<Post[]> {
    return Array.from(this.posts.values())
      .filter(post => post.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = randomUUID();
    const post: Post = { ...insertPost, id };
    this.posts.set(id, post);
    return post;
  }

  async deletePost(id: string): Promise<boolean> {
    return this.posts.delete(id);
  }

  // Stories
  async getStory(id: string): Promise<Story | undefined> {
    return this.stories.get(id);
  }

  async getStoriesByUser(userId: string): Promise<Story[]> {
    const now = new Date();
    return Array.from(this.stories.values())
      .filter(story => story.userId === userId && new Date(story.expiresAt) > now)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async getActiveStories(): Promise<Story[]> {
    const now = new Date();
    return Array.from(this.stories.values())
      .filter(story => new Date(story.expiresAt) > now)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async createStory(insertStory: InsertStory): Promise<Story> {
    const id = randomUUID();
    const story: Story = { ...insertStory, id };
    this.stories.set(id, story);
    return story;
  }

  async markStoryViewed(id: string): Promise<boolean> {
    const story = this.stories.get(id);
    if (!story) return false;
    story.isViewed = true;
    this.stories.set(id, story);
    return true;
  }

  // Comments
  async getCommentsByPost(postId: string): Promise<Comment[]> {
    return Array.from(this.comments.values())
      .filter(comment => comment.postId === postId)
      .sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = randomUUID();
    const comment: Comment = { ...insertComment, id };
    this.comments.set(id, comment);
    return comment;
  }

  async deleteComment(id: string): Promise<boolean> {
    return this.comments.delete(id);
  }

  // Likes
  async getLikesByPost(postId: string): Promise<Like[]> {
    return Array.from(this.likes.values())
      .filter(like => like.postId === postId);
  }

  async createLike(insertLike: InsertLike): Promise<Like> {
    const id = randomUUID();
    const like: Like = { ...insertLike, id };
    this.likes.set(id, like);
    return like;
  }

  async deleteLike(userId: string, postId: string): Promise<boolean> {
    const like = Array.from(this.likes.values())
      .find(l => l.userId === userId && l.postId === postId);
    if (!like) return false;
    return this.likes.delete(like.id);
  }

  async hasUserLikedPost(userId: string, postId: string): Promise<boolean> {
    return Array.from(this.likes.values())
      .some(like => like.userId === userId && like.postId === postId);
  }

  // Follows
  async getFollowers(userId: string): Promise<Follow[]> {
    return Array.from(this.follows.values())
      .filter(follow => follow.followingId === userId);
  }

  async getFollowing(userId: string): Promise<Follow[]> {
    return Array.from(this.follows.values())
      .filter(follow => follow.followerId === userId);
  }

  async createFollow(insertFollow: InsertFollow): Promise<Follow> {
    const id = randomUUID();
    const follow: Follow = { ...insertFollow, id };
    this.follows.set(id, follow);
    return follow;
  }

  async deleteFollow(followerId: string, followingId: string): Promise<boolean> {
    const follow = Array.from(this.follows.values())
      .find(f => f.followerId === followerId && f.followingId === followingId);
    if (!follow) return false;
    return this.follows.delete(follow.id);
  }

  async isFollowing(followerId: string, followingId: string): Promise<boolean> {
    return Array.from(this.follows.values())
      .some(follow => follow.followerId === followerId && follow.followingId === followingId);
  }

  // Notifications
  async getNotificationsByUser(userId: string): Promise<Notification[]> {
    return Array.from(this.notifications.values())
      .filter(notification => notification.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  }

  async createNotification(insertNotification: InsertNotification): Promise<Notification> {
    const id = randomUUID();
    const notification: Notification = { ...insertNotification, id };
    this.notifications.set(id, notification);
    return notification;
  }

  async markNotificationRead(id: string): Promise<boolean> {
    const notification = this.notifications.get(id);
    if (!notification) return false;
    notification.isRead = true;
    this.notifications.set(id, notification);
    return true;
  }

  async markAllNotificationsRead(userId: string): Promise<boolean> {
    Array.from(this.notifications.values())
      .filter(n => n.userId === userId)
      .forEach(n => {
        n.isRead = true;
        this.notifications.set(n.id, n);
      });
    return true;
  }

  // Reels
  async getReel(id: string): Promise<Reel | undefined> {
    return this.reels.get(id);
  }

  async getReels(limit: number, offset: number): Promise<Reel[]> {
    const allReels = Array.from(this.reels.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    return allReels.slice(offset, offset + limit);
  }

  async createReel(insertReel: InsertReel): Promise<Reel> {
    const id = randomUUID();
    const reel: Reel = { ...insertReel, id };
    this.reels.set(id, reel);
    return reel;
  }
}

export const storage = new MemStorage();
